The initial 1.1.1 qualification at source 4ff9a5d is retained.
field-replay allowed exactly20 owned-control LIST commands, excluding a legitimate
concurrent-CREATE verification. Actual LIST21/control-bootstrap LIST21; no broad
scan, throughput and RTT assertions passed. Corrected gate permits20..40 scoped
inventory/verification commands. No latency, throughput or mailbox cap changed.
short-runs: maximum idle/post337.093ms exceeded300ms. Raw job/ZIP retained.
recovered-client-replay: maximum idle/post302.137ms exceeded300ms. Raw retained.
The next full qualification uses byte-identical source and fixtures. Both failed
latency measurements are disclosed, rather than removed from the evidence.
