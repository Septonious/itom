//go:build linux

package mobile

import (
	"bytes"
	"context"
	"crypto/tls"
	"crypto/x509"
	"encoding/binary"
	"encoding/json"
	"io"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"sync/atomic"
	"testing"
	"time"

	"golang.org/x/net/dns/dnsmessage"
	"golang.org/x/net/proxy"
	"golang.org/x/sys/unix"
	"gvisor.dev/gvisor/pkg/tcpip"
	"gvisor.dev/gvisor/pkg/tcpip/adapters/gonet"
	"gvisor.dev/gvisor/pkg/tcpip/link/fdbased"
	"gvisor.dev/gvisor/pkg/tcpip/network/ipv4"
	"gvisor.dev/gvisor/pkg/tcpip/stack"
	"gvisor.dev/gvisor/pkg/tcpip/transport/tcp"
	"gvisor.dev/gvisor/pkg/tcpip/transport/udp"
)

type trafficHost struct{}

func (trafficHost) Protect(int) bool     { return true }
func (trafficHost) DNS() string          { return `["127.0.0.1"]` }
func (trafficHost) Lookup(string) string { return `["127.0.0.1"]` }
func (trafficHost) Route(string) string  { return "VPN" }
func (trafficHost) Startup(string) bool  { return true }

// Launched by the core's real LOGIN/SELECT/standing-server fixture. No native
// transport, crypto, exit bridge or application copy path is substituted.
// The datagram pair carries raw IPv4 packets, as an unprivileged TUN surrogate.
func TestRealNativeClientProcessHelper(t *testing.T) {
	input := os.Getenv("ITOM_NATIVE_TEST_CONFIG")
	if input == "" {
		return
	}
	dnsCounts := startupDNSFixture(t)
	raw, err := os.ReadFile(input)
	if err != nil {
		t.Fatal(err)
	}

	var document map[string]any
	if e := json.Unmarshal(raw, &document); e != nil {
		t.Fatal(e)
	}
	document["DNSResolver"] = map[string]any{"primary": "127.0.0.83", "backup": "127.0.0.84", "itom_fallback": false}
	raw, err = json.Marshal(document)
	if err != nil {
		t.Fatal(err)
	}
	c, err := New(string(raw), os.Getenv("ITOM_NATIVE_TEST_STATE"), trafficHost{})
	if err != nil {
		t.Fatal(err)
	}
	defer c.Close()
	defer func() {
		if t.Failed() {
			_ = os.WriteFile(os.Getenv("ITOM_NATIVE_TEST_EVIDENCE"), []byte(c.Diagnostics()), 0600)
		}
	}()
	roots := x509.NewCertPool()
	pem, err := os.ReadFile(os.Getenv("ITOM_NATIVE_TEST_HTTPS_ROOT"))
	if err != nil || !roots.AppendCertsFromPEM(pem) {
		t.Fatal("HTTPS trust", err)
	}
	pair, err := unix.Socketpair(unix.AF_UNIX, unix.SOCK_DGRAM|unix.SOCK_NONBLOCK, 0)
	if err != nil {
		t.Fatal(err)
	}
	if err = c.Attach(pair[0]); err != nil {
		unix.Close(pair[1])
		t.Fatal(err)
	}
	defer unix.Close(pair[1])
	link, err := fdbased.New(&fdbased.Options{FDs: []int{pair[1]}, MTU: 1500})
	if err != nil {
		t.Fatal(err)
	}
	app := stack.New(stack.Options{NetworkProtocols: []stack.NetworkProtocolFactory{ipv4.NewProtocol}, TransportProtocols: []stack.TransportProtocolFactory{tcp.NewProtocol, udp.NewProtocol}})
	defer app.Close()
	if e := app.CreateNIC(1, link); e != nil {
		t.Fatal(e)
	}
	if e := app.AddProtocolAddress(1, tcpip.ProtocolAddress{Protocol: ipv4.ProtocolNumber, AddressWithPrefix: tcpip.AddressWithPrefix{Address: tcpip.AddrFrom4([4]byte{172, 19, 0, 10}), PrefixLen: 24}}, stack.AddressProperties{}); e != nil {
		t.Fatal(e)
	}
	app.SetRouteTable([]tcpip.Route{{Destination: headerIPv4EmptySubnet(), NIC: 1}})
	socks, err := proxy.SOCKS5("tcp", c.listener.Addr().String(), nil, proxy.Direct)
	if err != nil {
		t.Fatal(err)
	}

	// A real UDP DNS packet crosses the emulated app's TUN before any HTTPS.
	socket, e := gonet.DialUDP(app, nil, &tcpip.FullAddress{NIC: 1, Addr: tcpip.AddrFrom4([4]byte{172, 19, 0, 2}), Port: 53}, ipv4.ProtocolNumber)
	if e != nil {
		t.Fatal(e)
	}
	_ = socket.SetDeadline(time.Now().Add(2 * time.Second))
	name, e := dnsmessage.NewName("example.com.")
	if e != nil {
		t.Fatal(e)
	}
	query, e := (&dnsmessage.Message{Header: dnsmessage.Header{ID: 1234, RecursionDesired: true}, Questions: []dnsmessage.Question{{Name: name, Type: dnsmessage.TypeA, Class: dnsmessage.ClassINET}}}).Pack()
	if e != nil {
		t.Fatal(e)
	}
	if _, e = socket.Write(query); e != nil {
		t.Fatal(e)
	}
	buffer := make([]byte, 4096)
	n, e := socket.Read(buffer)
	socket.Close()
	if e != nil {
		t.Fatal("actual TUN DNS", e)
	}
	var answer dnsmessage.Message
	if e = answer.Unpack(buffer[:n]); e != nil || answer.ID != 1234 || answer.RCode != dnsmessage.RCodeSuccess {
		t.Fatal("TUN DNS response", e)
	}
	var appIP [4]byte
	found := false
	for _, record := range answer.Answers {
		if a, ok := record.Body.(*dnsmessage.AResource); ok {
			appIP = a.A
			found = true
			break
		}
	}
	if !found {
		t.Fatal("TUN DNS returned no address")
	}
	if dnsCounts.udp.Load() == 0 || dnsCounts.tcp.Load() == 0 {
		t.Fatal("protected UDP/53 to TCP/53 fallback was not exercised")
	}
	t.Logf("TUN DNS and protected UDP/TCP 53 passed; udp=%d tcp=%d", dnsCounts.udp.Load(), dnsCounts.tcp.Load())
	for _, mode := range []string{"socks", "tun"} {
		tr := &http.Transport{TLSClientConfig: &tls.Config{RootCAs: roots, ServerName: "example.com"}, TLSHandshakeTimeout: 1500 * time.Millisecond, ResponseHeaderTimeout: 1500 * time.Millisecond}
		tr.DialContext = func(ctx context.Context, _, _ string) (net.Conn, error) {
			if mode == "socks" {
				return socks.(proxy.ContextDialer).DialContext(ctx, "tcp", "example.com:443")
			}
			return gonet.DialContextTCP(ctx, app, tcpip.FullAddress{NIC: 1, Addr: tcpip.AddrFrom4(appIP), Port: 443}, ipv4.ProtocolNumber)
		}
		hc := &http.Client{Transport: tr, Timeout: 5 * time.Second}
		for _, size := range []int{4096, 128 << 10} {
			payload := bytes.Repeat([]byte{37}, size)
			resp, e := hc.Post("https://example.com/", "application/octet-stream", bytes.NewReader(payload))
			if e != nil {
				t.Fatalf("%s size=%d HTTP: %v diagnostics=%s", mode, size, e, c.Diagnostics())
			}
			got, e := io.ReadAll(resp.Body)
			resp.Body.Close()
			if e != nil || !bytes.Equal(got, payload) {
				t.Fatalf("%s size=%d body=%d err=%v diagnostics=%s", mode, size, len(got), e, c.Diagnostics())
			}
		}
		tr.CloseIdleConnections()
	}
	var stats map[string]any
	if err = json.Unmarshal([]byte(c.Snapshot()), &stats); err != nil {
		t.Fatal(err)
	}
	if stats["Upload"].(float64) < 2*(4096+128<<10) || stats["Download"].(float64) < 2*(4096+128<<10) {
		t.Fatal("native application counters", stats)
	}
	if p := c.pool.Probe(); p.Samples == 0 || p.SampledAtMS <= 0 || p.Failure != "" {
		t.Fatalf("real peer echo missing: %+v", p)
	}
	if evidence := c.Diagnostics(); !strings.Contains(evidence, `"Session":`) || !strings.Contains(evidence, `"Native":`) {
		t.Fatal("runtime/bridge evidence missing", evidence)
	}
	trace, e := os.ReadFile(filepath.Join(os.Getenv("ITOM_NATIVE_TEST_STATE"), "transport", "transport-trace.jsonl"))
	if e != nil || !bytes.Contains(trace, []byte(`"client_runtime"`)) {
		t.Fatal("running client omitted runtime trace", e)
	}
	if err = os.WriteFile(os.Getenv("ITOM_NATIVE_TEST_STOP"), []byte("intentional fixture owner shutdown"), 0600); err != nil {
		t.Fatal(err)
	}
	t.Log("actual native SOCKS and IPv4 TUN HTTPS upload/download integrity passed")
	if os.Getenv("ITOM_NATIVE_TEST_CRASH") == "1" {
		// Real process death bypasses Client.Close and its reservation
		// checkpoint. The next independently launched native process must
		// recover publication debt without trusting an in-memory history.
		if err := unix.Kill(os.Getpid(), unix.SIGKILL); err != nil {
			t.Fatal(err)
		}
	}
}

func headerIPv4EmptySubnet() tcpip.Subnet {
	s, e := tcpip.NewSubnet(tcpip.AddrFrom4([4]byte{}), tcpip.MaskFromBytes([]byte{0, 0, 0, 0}))
	if e != nil {
		panic(e)
	}
	return s
}

// TC responses force the production resolver to use protected TCP/53.
type startupDNSCounts struct{ udp, tcp atomic.Int64 }

func startupDNSFixture(t *testing.T) *startupDNSCounts {
	t.Helper()
	counts := &startupDNSCounts{}
	reply := func(raw []byte, truncated bool) []byte {
		var q dnsmessage.Message
		if q.Unpack(raw) != nil || len(q.Questions) != 1 {
			return nil
		}
		q.Header.Response = true
		q.Header.Truncated = truncated
		q.Header.RCode = dnsmessage.RCodeSuccess
		if !truncated {
			q.Answers = []dnsmessage.Resource{{Header: dnsmessage.ResourceHeader{Name: q.Questions[0].Name, Type: dnsmessage.TypeA, Class: dnsmessage.ClassINET, TTL: 60}, Body: &dnsmessage.AResource{A: [4]byte{203, 0, 113, 80}}}}
		}
		b, _ := q.Pack()
		return b
	}
	for _, host := range []string{"127.0.0.83", "127.0.0.84"} {
		datagram, e := net.ListenPacket("udp4", host+":53")
		if e != nil {
			t.Fatal(e)
		}
		t.Cleanup(func() { datagram.Close() })
		go func() {
			buf := make([]byte, 4096)
			for {
				n, peer, e := datagram.ReadFrom(buf)
				if e != nil {
					return
				}
				counts.udp.Add(1)
				b := reply(buf[:n], true)
				_, _ = datagram.WriteTo(b, peer)
			}
		}()
		listener, e := net.Listen("tcp4", host+":53")
		if e != nil {
			t.Fatal(e)
		}
		t.Cleanup(func() { listener.Close() })
		go func() {
			for {
				c, e := listener.Accept()
				if e != nil {
					return
				}
				go func() {
					defer c.Close()
					_ = c.SetDeadline(time.Now().Add(time.Second))
					var head [2]byte
					if _, e := io.ReadFull(c, head[:]); e != nil {
						return
					}
					size := int(binary.BigEndian.Uint16(head[:]))
					if size < 12 || size > 4096 {
						return
					}
					raw := make([]byte, size)
					if _, e := io.ReadFull(c, raw); e != nil {
						return
					}
					counts.tcp.Add(1)
					b := reply(raw, false)
					binary.BigEndian.PutUint16(head[:], uint16(len(b)))
					_, _ = c.Write(append(head[:], b...))
				}()
			}
		}()
	}
	return counts
}
