# RC1 local evidence

Final runtime/build commit: a0eab8b412ce332fb7ee4446c1a608730c00a88c.
Hosted final safety evidence is separate and passes 253 core and 10 native groups.

This directory retains development failures as well as successes:
- endpoint-initial/second/third: new echo fixture responded before draining its request; corrected with complete read before write. No production body/size/deadline changed.
- endpoint-read-complete: 80 end-to-end TLS/HTTP exchanges and six DATA grants pass before final history integration.
- endpoint-restarts-first: surviving wallet reconciliation and missing-history retention pass.
- rc1-core-candidate and rc1-endpoint-final: retained deadline failures from local overlapping instrumented executions on the shared source host. They are not discarded or claimed resolved by a later pass.
- rc1-core-final: a retained isolated bounded-provider APPEND/EOF failure. It remains a local check concern; hosted exact-source checks pass separately.
- rc1-public-api-first: actual public API traffic and restart completed, but fixture flagged an intentionally interrupted shutdown APPEND. The corrected fixture permits incomplete literal EOF only during explicit endpoint shutdown; ordinary service/integrity bounds remain unchanged.
- rc1-public-api-corrected: public StartClientWithOptions and ServeManaged in a real server process, verified TLS and VPN restart pass.
- production-capacity: an explicit Go test overlay changes only protocol-fixture journal capacities to the actual original CONTROL 2MiB/128 and DATA 12MiB/192, MaxGrants/MaxAttempts 256. All 80 exchanges complete with six real DATA grants. This is a functional check, not bandwidth or RTT qualification. The complete overlay is retained; implementation code is unchanged.

The shared source host has a two-CPU cgroup. That fact does not identify the cause of each slow event and does not justify changing any timeout, dropping a sample or claiming field stability. No CPU settings, application deadlines or numerical performance gates were changed. Tagged maximum RTT gates from prior FETCH-overlap evidence remain unqualified. Current source safety CI evidence is attached separately.
