package org.itom.client

import android.os.SystemClock
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.serialization.json.*
import org.itom.domain.*
import java.util.Locale
import kotlinx.coroutines.delay

private fun readinessName(reason: String?): String = when (reason) {
    "ready" -> "Готов"
    "grants" -> "Ожидает разрешения на передачу"
    "reattaching" -> "Восстанавливается"
    "open_quarantine" -> "Ожидает восстановления TCP"
    "reader_stale" -> "Нет свежего ответа"
    "backoff" -> "Повтор подключения"
    "connecting" -> "Подключается"
    else -> "Ещё не готов"
}

private fun bytesText(value: String?): String = value?.toLongOrNull()?.let {
    String.format(Locale.ROOT, "%.1f МиБ", it / 1048576.0)
} ?: "—"

@Composable fun TransportOverview(config: PublicConfig, session: SessionSnapshot, view: TransportDiagnostics) {
    var now by remember { mutableLongStateOf(SystemClock.elapsedRealtime()) }
    LaunchedEffect(session.generation) { while (true) { now=SystemClock.elapsedRealtime(); delay(1000) } }
    val total = if (session.profileId != null) session.metrics.totalLines else config.selected?.totalLines ?: 0
    InfoCard(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Транспорт", style = MaterialTheme.typography.titleMedium)
            StatusLabel(phaseName(session.phase), phaseColor(session.phase))
        }
        Text("Почтовые линии: ${session.metrics.activeLines}/$total", style = MaterialTheme.typography.titleLarge)
        if (session.phase == Phase.CONNECTED && session.metrics.activeLines < total) {
            StatusLabel("${total-session.metrics.activeLines} линий временно недоступны", Yellow)
        }
        SmallNote("Готовность учитывает разрешения, ответы IMAP и возможность открыть TCP. Две линии на включённый аккаунт.")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Column(Modifier.weight(1f)) { SmallNote("RTT"); Text(Presentation.rtt(session.metrics.rttMs), color = rttColor(session.metrics.rttMs, config.settings.rttThresholds)) }
            Column(Modifier.weight(1f)) { SmallNote("TCP-потоки"); Text(session.metrics.tcp.toString()) }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Column(Modifier.weight(1f)) { SmallNote("Скачано"); Text(bytesText(view.root.field("Download"))) }
            Column(Modifier.weight(1f)) { SmallNote("Отправлено"); Text(bytesText(view.root.field("Upload"))) }
        }
        session.startedAt?.let { start ->
            val seconds = ((now - start).coerceAtLeast(0) / 1000)
            SmallNote("Время сессии: ${seconds / 60} мин ${seconds % 60} с")
        }
        session.sampledAt?.let { sampled ->
            val seconds = (now - sampled).coerceAtLeast(0) / 1000
            SmallNote("Последний снимок: $seconds с назад")
        } ?: SmallNote("Ждём первый снимок транспорта.")
        session.error?.let { DiagnosticCode(it, terminal = true) }
        if (session.sampledAt != null && !view.consistent(session.metrics)) {
            StatusLabel("Предупреждение · снимок линий неполный", Yellow)
            SmallNote("Счётчик выше достоверен. Обновите обе стороны до одной версии для детализации линий.")
        }
    }
    TransportChart(session)
}

private val detailNames = mapOf(
    "LastOperation" to "Последняя операция", "LastOperationMS" to "Длительность, мс",
    "MaxOperationMS" to "Максимум операции, мс", "RXAgeMS" to "С последнего ответа, мс",
    "RTTMillis" to "RTT, мс", "Reconnects" to "Переподключения", "Queue" to "Очередь управления",
    "Outbox" to "Неподтверждённые кадры", "AvailableGrants" to "Доступные grants",
    "IssuedGrants" to "Выданные grants", "PendingDescriptors" to "Ожидающие дескрипторы",
    "PendingRetirements" to "Ожидающие завершения", "IOConnections" to "Сокеты IMAP",
    "DataBytes" to "Занято данными, байт", "DataMessages" to "Писем с данными", "ControlMessages" to "Служебных писем",
    "DownloadWindowBytes" to "Окно приёма, байт",
    "DownloadBacklogBytes" to "Данные в пути, байт",
    "DownloadPendingBytes" to "Ожидающие APPEND, байт",
)

@Composable fun TransportLine(config: PublicConfig, session: SessionSnapshot, line: JsonObject) {
    val id = line.field("Account") ?: "—"
    val profile = config.profiles.find { it.profileId == session.profileId }
    val name = profile?.accounts?.find { it.id == id }?.name ?: id
    var expanded by rememberSaveable(session.generation, id) { mutableStateOf(false) }
    val ready = line.field("Ready")?.toBooleanStrictOrNull()
    val reason = line.field("ReadinessReason")
    val detailed = line.field("Extended") == "true"
    val color = when (ready) { true -> Green; false -> Yellow; null -> Muted }
    val active = line.field("ActiveLines") ?: "—"
    val total = line.field("TotalLines") ?: "—"
    InfoCard(Modifier.fillMaxWidth(), accent = color, contentPadding = 14.dp) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(name, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
            StatusLabel("$active/$total", color)
        }
        Text(if (ready == null) "Готовность не передана в снимке" else readinessName(reason), color = color, style = MaterialTheme.typography.bodySmall)
        SmallNote("RTT ${line.field("RTTMillis") ?: "—"} мс · IMAP ${if (detailed) line.field("LastOperationMS") ?: "—" else "—"} мс · очередь ${if (detailed) line.field("Queue") ?: "—" else "—"}")
        line.field("LastError")?.takeIf { it.isNotBlank() && it != "OK" }?.let {
            SmallNote("Последнее событие ошибки; готовность показана выше")
            DiagnosticCode(it)
        }
        if (!detailed) SmallNote("Для очередей, grants и истории операций включите расширенную диагностику.")
        TextButton(enabled = detailed, onClick = { expanded = !expanded }, modifier = Modifier.fillMaxWidth()) {
            Text(if (expanded) "Скрыть показатели" else "Все показатели аккаунта")
            Spacer(Modifier.width(6.dp)); AppIcon(if (expanded) Glyph.UP else Glyph.DOWN, Modifier.size(16.dp), Blue)
        }
        if (expanded && detailed) {
            HorizontalDivider(color = Outline)
            // Keep every native metric discoverable. Sections expand individually to
            // avoid laying out hundreds of rows during the periodic status poll.
            val fields = line.filterKeys { it !in setOf("Account", "Ready", "Extended", "ActiveLines", "TotalLines", "ReadinessReason", "LastError") }
            val groups = fields.entries.groupBy { (key, _) -> when {
                key == "LatencyGovernor" -> "Баланс RTT / скорости"
                key.contains("Grant") || key.contains("Descriptor") || key.contains("Window") || key.contains("Receipt") -> "Разрешения и подтверждения"
                key.contains("Cleanup") || key.contains("GC") || key.contains("Obsolete") || key.contains("Retire") -> "Очистка и хранение"
                key.contains("Wait") || key.contains("Queue") || key.contains("Stripe") || key.contains("Outbox") -> "Очереди и ожидание"
                key.contains("Append") || key.contains("Fetch") || key.contains("Idle") || key.contains("Record") || key.contains("Payload") || key.contains("Batch") || key.contains("Data") || key.contains("Control") -> "Передача IMAP"
                else -> "Соединение"
            } }
            groups.forEach { (title, values) -> MetricSection(title, JsonObject(values.associate { it.key to it.value }), "${session.generation}:$id") }
        }
    }
}

@Composable private fun MetricSection(title: String, values: JsonObject, identity: String) {
    var expanded by rememberSaveable(identity, title) { mutableStateOf(false) }
    TextButton(onClick = { expanded = !expanded }, modifier = Modifier.fillMaxWidth()) {
        Text(title, Modifier.weight(1f)); AppIcon(if (expanded) Glyph.UP else Glyph.DOWN, Modifier.size(16.dp), Blue)
    }
    if (expanded) values.forEach { (key, value) ->
        if (value is JsonObject) MetricRows(value) else MetricRow(key, (value as? JsonPrimitive)?.contentOrNull ?: "—")
    }
}

@Composable private fun MetricRows(values: JsonObject) {
    values.forEach { (key, value) -> if (value is JsonObject) MetricRows(value) else MetricRow(key, (value as? JsonPrimitive)?.contentOrNull ?: "—") }
}

@Composable private fun MetricRow(key: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        SmallNote(detailNames[key] ?: key, modifier = Modifier.weight(1.2f))
        Text(value, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
    }
}
