package org.itom.client

import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.*
import kotlinx.serialization.json.*
import org.itom.domain.*

@Composable fun SettingsScreen(navigate: (Page) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        NavigationRow(Glyph.NETWORK, "SOCKS5", "Порт и авторизация") { navigate(Page.SOCKS) }
        NavigationRow(Glyph.BELL, "Уведомление", "Разрешение и настройки Android") { navigate(Page.NOTIFICATION) }
        NavigationRow(Glyph.CHART, "Диагностика", "Состояние подключения и экспорт отчёта") { navigate(Page.DIAGNOSTICS) }
    }
}

@Composable fun NotificationScreen() {
    val context = LocalContext.current
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    var enabled by remember(context) { mutableStateOf(NotificationManagerCompat.from(context).areNotificationsEnabled()) }
    DisposableEffect(context, lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) enabled = NotificationManagerCompat.from(context).areNotificationsEnabled()
        }
        lifecycle.addObserver(observer)
        onDispose { lifecycle.removeObserver(observer) }
    }
    PageColumn {
        InfoCard(Modifier.fillMaxWidth()) {
            Text("Уведомления ITOM", style = MaterialTheme.typography.titleMedium)
            Text(if (enabled) "Уведомления разрешены" else "Уведомления отключены в Android")
            SmallNote("При работающем VPN уведомление показывает текущие скорости и RTT.")
        }
        NavigationRow(Glyph.BELL, "Настройки Android", "Разрешение и отображение уведомлений") { context.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)) }
    }
}

@Composable fun DiagnosticsScreen(config: PublicConfig, session: SessionSnapshot, diagnostics: String, onDiagnosticsChanged: (Boolean) -> Unit, onMessage: (String) -> Unit) {
    val context = LocalContext.current; val scope = rememberCoroutineScope()
    var report by rememberSaveable { mutableStateOf<String?>(null) }
    val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        val text = report; report = null
        if (uri != null && text != null) scope.launch {
            try {
                withContext(Dispatchers.IO) { context.contentResolver.openOutputStream(uri, "wt")?.use { it.write(text.toByteArray()) } ?: throw DomainError("EXPORT_FAILED") }
                onMessage("Диагностический отчёт сохранён.")
            } catch (e: CancellationException) { throw e } catch (_: Exception) { onMessage("Не удалось сохранить отчёт.") }
        }
    }
    fun currentReport(): String {
        return Codec.json.encodeToString(JsonObject.serializer(), buildJsonObject {
                put("schema_version", 5); put("build", BuildConfig.VERSION_NAME); put("ui_baseline", BuildConfig.UI_BASELINE)
                put("android_api", Build.VERSION.SDK_INT); put("phase", session.phase.name); put("generation", session.generation)
                put("configuration_revision", config.revision); put("profile_count", config.profiles.size)
                put("vpn_interface_up", session.vpnInterfaceUp); put("down_bps", session.metrics.downBps); put("up_bps", session.metrics.upBps)
                put("rtt_ms", session.metrics.rttMs?.let(::JsonPrimitive) ?: JsonNull)
                put("tcp", session.metrics.tcp); put("active_lines", session.metrics.activeLines); put("total_lines", session.metrics.totalLines)
                put("error_code", session.error?.let(::JsonPrimitive) ?: JsonNull)
                put("transport", runCatching { Codec.json.parseToJsonElement(diagnostics) }.getOrDefault(JsonObject(emptyMap())))
            })
    }
    var zipReport by rememberSaveable { mutableStateOf<String?>(null) }
    var zipProfile by rememberSaveable { mutableStateOf<String?>(null) }
    val exportZip = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        val text = zipReport; val profile = zipProfile; zipReport = null; zipProfile = null
        if (uri != null && text != null) scope.launch {
            try {
                withContext(Dispatchers.IO) {
                    context.contentResolver.openOutputStream(uri, "wt")?.use { output ->
                        exportTransportTrace(context.noBackupFilesDir, profile, text, output)
                    } ?: throw DomainError("EXPORT_FAILED")
                }
                onMessage("Архив диагностики сохранён.")
            } catch (e: CancellationException) { throw e } catch (_: Exception) { onMessage("Не удалось сохранить архив.") }
        }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        InfoCard(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(Modifier.weight(1f)) {
                    Text("Логи и трассировка", style = MaterialTheme.typography.titleMedium)
                    SmallNote(if (config.settings.diagnosticsEnabled) "Включены. Используйте только для диагностики: запись событий повышает нагрузку и расход батареи." else "Выключены. Файловая трассировка и расширенный фоновый сбор диагностики не выполняются.")
                }
                Switch(checked = config.settings.diagnosticsEnabled, onCheckedChange = onDiagnosticsChanged)
            }
        }
        InfoCard(Modifier.fillMaxWidth()) {
            Text("Состояние приложения", style = MaterialTheme.typography.titleMedium)
            SmallNote("${BuildConfig.VERSION_NAME} · Android API ${Build.VERSION.SDK_INT}")
            Text("Хранилище: ${if (config.error == null) "доступно" else "ошибка"}")
            Text("Профилей: ${config.profiles.size} · ревизия: ${config.revision}")
            Text("Сессия: ${phaseName(session.phase)} · generation: ${session.generation}")
            Text("VPN-интерфейс: ${if (session.vpnInterfaceUp) "поднят" else "закрыт"}")
        }
        val view = remember(diagnostics) { TransportDiagnostics.parse(diagnostics) }
        TransportOverview(config, session, view)
        view.root.objectField("Trace")?.let { trace ->
            InfoCard(Modifier.fillMaxWidth()) {
                Text("Запись трассировки", style = MaterialTheme.typography.titleMedium)
                SmallNote("${trace.field("Written") ?: "0"} событий · пропущено ${trace.field("Dropped") ?: "0"} · ошибок записи ${trace.field("WriteErrors") ?: "0"}")
                if ((trace.field("Dropped")?.toLongOrNull() ?: 0) > 0 || (trace.field("WriteErrors")?.toLongOrNull() ?: 0) > 0) StatusLabel("Предупреждение · трассировка неполная", Yellow)
            }
        }
        Text("Почтовые аккаунты", style = MaterialTheme.typography.titleMedium)
        if (view.lines.isEmpty()) SmallNote("Данные появятся после начала подключения.")
        view.lines.forEach { line -> TransportLine(config, session, line) }
        SmallNote("Отчёт содержит состояние линий, технические ID аккаунтов, задержки IMAP, очереди и последние события. Адреса, логины, пароли, ключи и посещённые домены исключены.")
        GradientButton("Экспорт диагностики", onClick = {
            report = currentReport()
            export.launch("ITOM_diagnostics.json")
        }, modifier = Modifier.fillMaxWidth(), glyph = Glyph.DOWN)
        SmallNote("Полный архив дополнительно содержит события каждого транспортного кадра и зашифрованные тела пакетов. Журнал ограничен 48 МиБ и обновляется по кругу; содержимое TCP, пароли и ключи не записываются.")
        GradientButton("Экспорт полной трассировки", onClick = {
            zipReport = currentReport()
            zipProfile = session.profileId ?: config.selectedProfileId
            exportZip.launch("ITOM_diagnostics_full.zip")
        }, modifier = Modifier.fillMaxWidth(), enabled = config.settings.diagnosticsEnabled, glyph = Glyph.DOWN)
    }
}
