package org.itom.client

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.TextAutoSize
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.itom.domain.*

val Blue = Color(0xFF45AFFF)
val ActionBlue = Color(0xFF1266B5)
val Green = Color(0xFF48E5AE)
val Yellow = Color(0xFFF5C65B)
val Red = Color(0xFFFF6C86)
val Ink = Color(0xFFECF4FC)
val Muted = Color(0xFF93ABBD)
val Panel = Color(0xFF0D2030)
val Background = Color(0xFF050F18)
val Outline = Color(0xFF294457)

fun phaseColor(p: Phase) = when (p) { Phase.OFF -> Color(0xFF8193A4); Phase.CONNECTING -> Yellow; Phase.CONNECTED -> Green; Phase.ERROR -> Red }
fun phaseName(p: Phase) = when (p) { Phase.OFF -> "Отключено"; Phase.CONNECTING -> "Подключается"; Phase.CONNECTED -> "Подключено"; Phase.ERROR -> "Отключено из-за ошибки" }
fun routeName(action: RouteAction) = when (action) { RouteAction.VPN -> "VPN"; RouteAction.BLOCK -> "Block"; RouteAction.DIRECT -> "Direct" }
fun routeColor(action: RouteAction) = when (action) { RouteAction.VPN -> Blue; RouteAction.BLOCK -> Red; RouteAction.DIRECT -> Green }
fun rttColor(ms: Int?, t: RttThresholds) = when (Presentation.rttBand(ms, t)) { 1 -> Green; 2 -> Yellow; 3 -> Red; else -> Muted }
fun appModeName(mode: AppMode) = when (mode) { AppMode.ALL -> "Все приложения в VPN"; AppMode.EXCLUDE_SELECTED -> "Выбранные напрямую"; AppMode.INCLUDE_SELECTED -> "Только выбранные в VPN" }

@Composable fun ItomTheme(content: @Composable () -> Unit) {
    // Keep Android's font scale; the removed in-app multiplier is no longer applied.
    MaterialTheme(
        colorScheme = darkColorScheme(primary = Blue, onPrimary = Ink, secondary = Green, onSecondary = Ink,
            background = Background, surface = Panel, onBackground = Ink, onSurface = Ink,
            surfaceVariant = Color(0xFF152B3C), onSurfaceVariant = Muted, outline = Outline,
            outlineVariant = Outline.copy(alpha = .6f), error = Red, onError = Ink,
            primaryContainer = Color(0xFF123D60), onPrimaryContainer = Ink,
            secondaryContainer = Color(0xFF174967), onSecondaryContainer = Ink,
            tertiaryContainer = Color(0xFF174967), onTertiaryContainer = Ink,
            inverseSurface = Color(0xFF183348), inverseOnSurface = Ink, inversePrimary = Blue),
        shapes = Shapes(small = RoundedCornerShape(12.dp), medium = RoundedCornerShape(18.dp), large = RoundedCornerShape(24.dp)),
        typography = Typography(
            headlineSmall = TextStyle(fontSize = 24.sp, lineHeight = 30.sp, fontWeight = FontWeight.Medium),
            titleLarge = TextStyle(fontSize = 22.sp, lineHeight = 28.sp, fontWeight = FontWeight.Medium),
            titleMedium = TextStyle(fontSize = 16.sp, lineHeight = 22.sp, fontWeight = FontWeight.Medium),
            bodyLarge = TextStyle(fontSize = 15.sp, lineHeight = 22.sp),
            bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
            bodySmall = TextStyle(fontSize = 12.sp, lineHeight = 17.sp),
            labelLarge = TextStyle(fontSize = 14.sp, lineHeight = 19.sp, fontWeight = FontWeight.Medium),
            labelMedium = TextStyle(fontSize = 12.sp, lineHeight = 16.sp, fontWeight = FontWeight.Medium),
            labelSmall = TextStyle(fontSize = 11.sp, lineHeight = 14.sp, fontWeight = FontWeight.Medium)
        ), content = {
            // Gradient panels are Columns, not Surfaces: establish their inherited text color explicitly.
            CompositionLocalProvider(LocalContentColor provides Ink, content = content)
        }
    )
}

@Composable fun ItomBackdrop(content: @Composable BoxScope.() -> Unit) {
    Box(Modifier.fillMaxSize().background(Background).drawBehind {
        drawRect(Brush.verticalGradient(listOf(Color(0xFF0D1C2A), Background)))
        val radius = size.maxDimension.coerceAtLeast(1f) * .7f
        drawCircle(Brush.radialGradient(listOf(Blue.copy(alpha = .065f), Color.Transparent), Offset(size.width, 0f), radius), radius, Offset(size.width, 0f))
    }, content = content)
}

@Composable fun PageColumn(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(14.dp), content = content)
}

@Composable fun InfoCard(
    modifier: Modifier = Modifier, accent: Color? = null, contentPadding: Dp = 16.dp,
    onClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(22.dp)
    Column(modifier.clip(shape)
        .background(Brush.linearGradient(listOf(accent?.copy(alpha = .12f) ?: Color(0xFF132A3B), Color(0xFF0B1B29))))
        .border(1.dp, Brush.linearGradient(listOf(accent?.copy(alpha = .48f) ?: Color(0xFF375166), Outline.copy(alpha = .55f))), shape)
        .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
        .padding(contentPadding), verticalArrangement = Arrangement.spacedBy(8.dp), content = content)
}

@Composable fun SmallNote(text: String, color: Color = Muted, modifier: Modifier = Modifier) {
    Text(text, modifier = modifier, color = color, style = MaterialTheme.typography.bodySmall)
}

/** Bounded, single-line labels adapt locally without changing the system font scale. */
@Composable fun FitText(text: String, modifier: Modifier = Modifier, color: Color = Ink, maxSize: Int = 28, minSize: Int = 14, align: TextAlign = TextAlign.Start) {
    BasicText(text, modifier, style = MaterialTheme.typography.bodyLarge.copy(color = color, fontWeight = FontWeight.Medium,
        fontFeatureSettings = "tnum", textAlign = align, lineHeight = TextUnit.Unspecified), maxLines = 1, overflow = TextOverflow.Ellipsis,
        autoSize = TextAutoSize.StepBased(minFontSize = minSize.sp, maxFontSize = maxSize.sp, stepSize = 1.sp))
}
