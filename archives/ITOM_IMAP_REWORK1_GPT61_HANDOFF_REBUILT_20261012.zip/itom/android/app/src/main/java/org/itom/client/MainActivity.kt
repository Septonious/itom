package org.itom.client

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import org.itom.domain.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT))
        val graph = (application as ItomApplication).graph
        setContent { ItomApp(graph) }
    }
}

enum class Page(val title: String, val root: String) {
    HOME("ITOM", "home"), PROFILES("Профили", "profiles"), RULES("Правила", "rules"), SETTINGS("Настройки", "settings"),
    APPS("Приложения", "rules"), IMPORT("Добавить сервер", "profiles"), EDIT_PROFILE("Редактор профиля", "profiles"), DASHBOARD("Статистика", "home"),
    SOCKS("SOCKS5", "settings"), NOTIFICATION("Уведомление", "settings"), DIAGNOSTICS("Диагностика", "settings")
}

fun errorText(code: String) = when (code) {
    "SOCKS_PORT" -> "Порт SOCKS должен быть числом от 1024 до 65535."
    "SOCKS_CREDENTIALS" -> "Логин и пароль: от 1 до 255 байт UTF-8, без переносов строк."
    "SOCKS_EDIT_CONFLICT" -> "Настройки изменились. Откройте SOCKS5 заново перед сохранением."
    "EMPTY_INCLUDE" -> "Выберите хотя бы одно приложение."
    "APP_NOT_INSTALLED" -> "Часть выбранных приложений удалена. Обновите список и выбор."
    "SHARED_UID_PARTIAL_SELECTION" -> "Приложения с общим Android UID нужно выбирать вместе."
    "DUPLICATE_SERVER" -> "Профиль этого сервера уже добавлен."
    "PROFILE_MISSING" -> "Профиль удалён или больше недоступен."
    "PROFILE_EDIT_CONFLICT" -> "Данные изменились после открытия редактора. Загрузите актуальный профиль перед сохранением."
    "PROFILE_NAME", "ACCOUNT_NAME" -> "Название должно содержать от 1 до 80 символов без управляющих знаков."
    "SERVER_ID", "PAIR_ID" -> "Server ID и Pair ID должны содержать 32 шестнадцатеричных символа."
    "USER_ID" -> "User ID должен содержать ровно 8 цифр и не начинаться с нуля."
    "PROVIDER_ID" -> "Провайдер: до 64 латинских строчных букв, цифр, дефисов или подчёркиваний."
    "FOLDER_NAMESPACE" -> "Проверьте папки: 2–128 латинских букв, цифр, точек, дефисов, подчёркиваний и /; пустые сегменты и .. недопустимы."
    "PSK_FORMAT" -> "Ключ должен содержать 32 байта, закодированных в Base64."
    "ACCOUNT_COUNT" -> "Нужны 1–64 аккаунта, хотя бы один из них включён."
    "ACCOUNT_ID" -> "ID аккаунта: 1–64 латинские буквы, цифры, дефисы или подчёркивания."
    "DUPLICATE_ACCOUNT" -> "ID аккаунтов внутри профиля должны различаться."
    "IMAP_PORT" -> "Порт IMAP должен быть числом от 1 до 65535."
    "IMAP_HOST" -> "Укажите домен или IP IMAP-сервера без схемы, пути и порта."
    "CREDENTIAL_FORMAT" -> "Проверьте логины и пароли аккаунтов: оба поля обязательны, переносы строк недопустимы."
    "MIXED_PROVIDERS" -> "Все аккаунты сервера должны принадлежать одному провайдеру."
    "INVITATION_EXPIRED" -> "Срок действия приглашения истёк."
    "VAULT_UNAVAILABLE" -> "Защищённое хранилище недоступно. Данные сохранены; повторите после разблокировки устройства."
    "VAULT_WRITE_FAILED" -> "Не удалось подтвердить сохранение. Проверьте свободное место и нажмите «Повторить», чтобы перечитать данные."
    "VPN_PERMISSION_REQUIRED", "VPN_PERMISSION_REVOKED" -> "Для подключения разрешите ITOM создавать VPN."
    "NO_NETWORK", "UNDERLYING_DNS_MISSING" -> "Нет доступной сети или её DNS-серверов."
    "SOCKS_PORT_IN_USE" -> "Порт SOCKS занят. Выберите другой в настройках."
    "TRANSPORT_TIMEOUT" -> "Связь с сервером не восстановлена. VPN отключён."
    "TRANSPORT_FAILED", "VPN_SERVICE_START_FAILED" -> "Не удалось запустить транспорт. Проверьте сервер и профиль."
    "INVALID_JSON", "DUPLICATE_JSON_KEY", "INVITATION_FORMAT", "INVITATION_VERSION" -> "Неверный формат приглашения."
    "DOCUMENT_TOO_LARGE" -> "Файл превышает допустимый размер."
    "QR_NOT_FOUND" -> "QR-код с приглашением не найден на изображении."
    else -> "Операция не выполнена: $code"
}

@Composable fun ItomApp(graph: AppGraph) {
    val config by graph.vault.state.collectAsStateWithLifecycle()
    val session by graph.backend.snapshot.collectAsStateWithLifecycle()
    var page by rememberSaveable { mutableStateOf(Page.HOME) }
    var editingProfileId by rememberSaveable { mutableStateOf<String?>(null) }
    var orbit by rememberSaveable { mutableFloatStateOf(35f) }
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    fun message(text: String) { scope.launch { snackbar.showSnackbar(text) } }
    fun perform(block: suspend () -> Unit) {
        if (busy) return
        busy = true
        scope.launch {
            try { block() } catch (e: CancellationException) { throw e }
            catch (e: DomainError) { snackbar.showSnackbar(errorText(e.code)) }
            catch (_: Exception) { snackbar.showSnackbar("Операция не выполнена. Попробуйте ещё раз.") }
            finally { busy = false }
        }
    }
    val consent = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            val current = graph.vault.state.value
            current.selected?.let { graph.backend.start(it, current.revision) }
        }
    }
    fun requestVPN() {
        val current = graph.vault.state.value
        val selected = current.selected ?: return
        val permission = android.net.VpnService.prepare(graph.context)
        if (permission != null) consent.launch(permission) else graph.backend.start(selected, current.revision)
    }
    val notifications = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestPermission()) { requestVPN() }
    fun startSelected() {
        val current = graph.vault.state.value
        val profile = current.selected
        if (current.loading || current.error != null) { message(errorText("VAULT_UNAVAILABLE")); return }
        if (profile == null) { page = Page.PROFILES; return }
        if (profile.profileId in current.incompleteProfileIds) {
            editingProfileId = profile.profileId; page = Page.EDIT_PROFILE
            message("Заполните ключ шифрования и данные всех IMAP-аккаунтов."); return
        }
        if (android.os.Build.VERSION.SDK_INT >= 33 && androidx.core.content.ContextCompat.checkSelfPermission(graph.context, android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            notifications.launch(android.Manifest.permission.POST_NOTIFICATIONS)
            return
        }
        requestVPN()
    }
    fun restartIfActive() {
        if (graph.backend.snapshot.value.phase in listOf(Phase.CONNECTING, Phase.CONNECTED)) startSelected()
    }
    fun toggle() {
        if (graph.backend.snapshot.value.phase in listOf(Phase.CONNECTING, Phase.CONNECTED)) graph.backend.stop()
        else startSelected()
    }
    fun back() { page = when (page.root) { "rules" -> Page.RULES; "profiles" -> Page.PROFILES; "settings" -> Page.SETTINGS; else -> Page.HOME } }
    BackHandler(page !in listOf(Page.HOME, Page.PROFILES, Page.RULES, Page.SETTINGS)) { back() }
    ItomTheme {
      ItomBackdrop {
        Scaffold(containerColor = Color.Transparent, contentColor = Ink, contentWindowInsets = WindowInsets.safeDrawing, topBar = {
            if (page !in listOf(Page.APPS, Page.EDIT_PROFILE)) ItomTopBar(page, ::back, { page = Page.DIAGNOSTICS }, { page = Page.NOTIFICATION })
        }, bottomBar = {
            // Editors own their header, Back handling and save bar.
            if (page !in listOf(Page.APPS, Page.EDIT_PROFILE)) ItomBottomBar(page) { page = it }
        }, snackbarHost = { SnackbarHost(snackbar) }) { padding ->
            Box(Modifier.fillMaxSize().padding(padding).consumeWindowInsets(padding).imePadding()) {
                when {
                    config.loading -> CircularProgressIndicator(Modifier.padding(24.dp))
                    config.error != null -> PageColumn { Text(errorText(config.error!!)); GradientButton("Повторить", { scope.launch { graph.vault.load() } }) }
                    else -> when (page) {
                        Page.HOME -> HomeScreen(config, session, { orbit }, { orbit = it }, ::toggle, { page = Page.PROFILES })
                        Page.PROFILES -> ProfilesScreen(config, busy, onSelect = { id -> perform { graph.vault.select(id); restartIfActive() } },
                            onEdit = { id -> editingProfileId = id; page = Page.EDIT_PROFILE }, onDelete = { id -> perform {
                                if (graph.backend.snapshot.value.profileId == id) graph.backend.stop()
                                graph.vault.remove(id)
                                // Start may have been tapped while the disk transaction was in flight.
                                if (graph.backend.snapshot.value.profileId == id) graph.backend.stop()
                            } }, onImport = { page = Page.IMPORT },
                            onMessage = ::message)
                        Page.RULES -> RulesScreen(config.settings.routing, config.settings.appRouting, busy, { page = Page.APPS }) { action, entries -> perform { graph.vault.rules(action, entries); restartIfActive(); message("Правила ${routeName(action)} сохранены.") } }
                        Page.APPS -> AppsScreen(config.settings.appRouting, graph.catalog, busy, ::back) { policy, _ -> perform { graph.vault.apps(policy, graph.catalog.load()); restartIfActive(); page = Page.RULES } }
                        Page.IMPORT -> ImportScreen(busy, ::message) { invitation -> perform { graph.vault.importInvitation(invitation); restartIfActive(); page = Page.PROFILES } }
                        Page.EDIT_PROFILE -> {
                            val id = editingProfileId
                            if (id == null) LaunchedEffect(Unit) { page = Page.PROFILES }
                            else ProfileEditorScreen(id, graph, close = { editingProfileId = null; page = Page.PROFILES }, saved = { restartFailed ->
                                editingProfileId = null; page = Page.PROFILES
                                message(if (restartFailed) "Профиль сохранён. Подключитесь заново." else "Профиль сохранён.")
                            })
                        }
                        Page.DASHBOARD, Page.DIAGNOSTICS -> DiagnosticsScreen(config, session, session.transport, { enabled -> perform { graph.vault.diagnostics(enabled); restartIfActive(); message(if (enabled) "Логи и трассировка включены." else "Логи и трассировка выключены.") } }, ::message)
                        Page.SETTINGS -> SettingsScreen { page = it }
                        Page.SOCKS -> SocksScreen(graph, onSaved = { restartIfActive(); page = Page.SETTINGS; message("Настройки SOCKS5 сохранены.") })
                        Page.NOTIFICATION -> NotificationScreen()
                    }
                }
            }
        }
      }
    }
}
