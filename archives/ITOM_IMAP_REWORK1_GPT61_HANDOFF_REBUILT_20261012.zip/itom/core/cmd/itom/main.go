package main

import (
	"context"
	"errors"
	"flag"
	"fmt"
	"itom.local/core/manager"
	"itom.local/core/probe"
	"itom.local/core/servercfg"
	"itom.local/core/tunnel"
	"log"
	"os"
	"os/signal"
	"path/filepath"
	"runtime"
)

const revision = "transport-rework1-field79"

func run(args []string) error {
	command := "menu"
	if len(args) > 0 {
		command = args[0]
		args = args[1:]
	}
	if command == "version" || command == "--version" {
		fmt.Println("ITOM", revision, runtime.GOOS, runtime.GOARCH)
		return nil
	}
	if command == "install" {
		return manager.Install()
	}
	flags := flag.NewFlagSet(command, flag.ContinueOnError)
	state := flags.String("state", "/var/lib/itom", "private state directory")
	profile := flags.String("profile", "", "CLI profile JSON")
	account := flags.String("account", "", "account email (required for imap-check)")
	to := flags.String("to", "", "offline DATA journal profile: data8, data12 or data16")
	if e := flags.Parse(args); e != nil {
		return e
	}
	if flags.NArg() != 0 {
		return errors.New("unexpected arguments")
	}
	switch command {
	case "imap-check":
		cfg, e := servercfg.Load(filepath.Join(*state, "server.db"))
		if e != nil {
			return e
		}
		ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, terminationSignal())
		defer stop()
		return probe.CheckIMAP(ctx, cfg, *account, os.Stdout)
	case "journal-profile":
		if *to != "data8" && *to != "data12" && *to != "data16" {
			return errors.New("--to=data8, --to=data12 or --to=data16 required; stop itom service first")
		}
		cfg, e := servercfg.Load(filepath.Join(*state, "server.db"))
		if e != nil {
			return e
		}
		for _, a := range cfg.Accounts {
			for _, u := range cfg.Users {
				dir := filepath.Join(*state, "tunnel-server", a.ID, u.ID)
				if _, e = os.Stat(filepath.Join(dir, "data.db")); errors.Is(e, os.ErrNotExist) {
					continue
				}
				if e != nil {
					return e
				}
				if e = tunnel.MigrateDataProfile(dir, a, u, *to); e != nil {
					return fmt.Errorf("account=%s user=%s profile=%s: %w", a.Mail.Username, u.ID, *to, e)
				}
				fmt.Printf("account=%s user=%s profile=%s outcome=audited\n", a.Mail.Username, u.ID, *to)
			}
		}
		return nil
	case "menu":
		return manager.New(*state).Run()
	case "serve":
		cfg, e := servercfg.Load(filepath.Join(*state, "server.db"))
		if e != nil {
			return e
		}
		ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, terminationSignal())
		defer stop()
		log.Printf("event=server_start revision=%s protocol=4 accounts=%d users=%d", revision, len(cfg.Accounts), len(cfg.Users))
		e = tunnel.Serve(ctx, cfg, filepath.Join(*state, "tunnel-server"), func(s string) { log.Print(s) })
		if errors.Is(e, context.Canceled) {
			return nil
		}
		return e
	case "probe":
		if *profile == "" {
			return errors.New("--profile required")
		}
		p, e := servercfg.ReadProfile(*profile)
		if e != nil {
			return e
		}
		dir := *state
		if dir == "/var/lib/itom" {
			cache, e := os.UserCacheDir()
			if e != nil {
				return e
			}
			dir = filepath.Join(cache, "itom-probe", fmt.Sprintf("%x", p.Server), p.User.ID, *account)
		}
		ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt)
		defer stop()
		rtt, e := probe.RunClient(ctx, p, *account, dir)
		if e != nil {
			return e
		}
		fmt.Printf("Noise + IMAP roundtrip OK; account=%s RTT=%s\n", *account, rtt.Round(1e6))
		return nil
	default:
		return errors.New("commands: menu, serve, probe, imap-check, install, version, journal-profile")
	}
}
func main() {
	if e := run(os.Args[1:]); e != nil {
		fmt.Fprintln(os.Stderr, "ITOM:", e)
		os.Exit(1)
	}
}
