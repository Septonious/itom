package tunnel

import "time"

// Stream complete BODYs immediately but amortize command RTT when the tail is
// full. Never raise the protocol's 16-UID bound; slow fetches and empty polls
// shrink the next turn. The IDLE/wake decision remains separate from batching.
type receivePagePolicy struct{ limit uint32 }

func (p *receivePagePolicy) size(hot bool) uint32 {
	if p.limit == 0 {
		p.limit = 4
	}
	if hot {
		return min(p.limit, 4)
	}
	return p.limit
}
func (p *receivePagePolicy) observe(limit uint32, rows int, elapsed time.Duration) {
	if elapsed >= 300*time.Millisecond {
		p.limit = 4
		return
	}
	if rows >= int(limit) {
		p.limit = min(uint32(16), max(uint32(4), limit*2))
	} else if rows == 0 {
		p.limit = max(uint32(4), limit/2)
	}
}
