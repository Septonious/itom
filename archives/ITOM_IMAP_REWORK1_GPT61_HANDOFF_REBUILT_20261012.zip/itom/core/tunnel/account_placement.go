package tunnel

import (
	"sort"
)

// Stable rotated ties retain account fairness. Cost includes work already
// admitted by the shared service, physical writer occupancy, peer BODY debt,
// and control debt. Reservation still occurs atomically in the existing grant
// and physical-slot paths; an estimate is never an authorization to publish.
func (g *stripeGroup) prioritizeBulkTargetsLocked(keys []string) {
	if len(keys) == 0 {
		return
	}
	start := int(g.turn % uint64(len(keys)))
	rotated := append(append([]string(nil), keys[start:]...), keys[:start]...)
	copy(keys, rotated)
	cost := func(l *lane) int64 {
		if l == nil {
			return 1 << 60
		}
		n := int64(len(l.physicalSlots))*65 + l.unreceivedLocalBytes.Load()/(32<<10) + int64(l.controlDebt.Load())
		if m, ok := l.mail.(interface{ DataQueueCost() int64 }); ok {
			n += m.DataQueueCost()
		}
		return n
	}
	sort.SliceStable(keys, func(i, j int) bool { return cost(g.lanes[keys[i]]) < cost(g.lanes[keys[j]]) })
}
func (m *observedMail) DataQueueCost() int64 {
	if d, ok := m.Transport.(interface{ DataQueueCost() int64 }); ok {
		return d.DataQueueCost()
	}
	return 0
}
