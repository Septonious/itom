package tunnel

import "time"

// Only client short DATA expects a fresh reply. Prime the deterministic quiet
// receive reserve across physical stripes, not just the logical owner's reader.
// Reply DATA and repairs must not create reciprocal polling storms.
func (g *stripeGroup) expectFastResponse(owner *lane) {
	if g == nil || owner == nil || owner.side {
		return
	}
	g.mu.Lock()
	quiet := g.interactiveReadersLocked()
	g.mu.Unlock()
	budget := owner.readerResponseBudget(650 * time.Millisecond)
	if quiet[0] == nil {
		owner.armReaderHot(budget)
		return
	}
	for _, l := range quiet {
		if l != nil {
			l.armReaderHot(budget)
		}
	}
}

func (l *lane) readerResponseBudget(base time.Duration) time.Duration {
	if rtt := l.rtt.Load(); rtt > 0 {
		base = max(base, time.Duration(min(rtt, 1000))*2*time.Millisecond+100*time.Millisecond)
	}
	return min(base, 2*time.Second)
}

func (l *lane) armReaderHot(budget time.Duration) {
	now := time.Now()
	until := now.Add(budget)
	extendReaderHot(&l.readHotUntil, until.UnixNano())
	if hot, ok := l.mail.(interface{ SetReaderHot(time.Time) }); ok {
		hot.SetReaderHot(until)
	}
	l.readHotGeneration.Add(1)
	// A request is fresh demand even inside an existing response window. Wake
	// the current empty poll as well as IDLE; the one-slot signal coalesces bursts.
	// Checking only the old expiry can also race entry into IDLE at that expiry.
	l.wakeReader()
}

// Keep two deterministic BODY readers free of new bulk admissions in pools of
// at least five usable accounts. Their control, short DATA and cleanup remain
// live. Temporary control debt must not rotate the reserve into bulk traffic.
// Caller holds g.mu; existing physical reservations finish normally.
func (g *stripeGroup) interactiveReadersLocked() [2]*lane {
	var best [2]*lane
	n := 0
	for _, l := range g.lanes {
		if l == nil || !l.streamCarrierReady() || l.ctx.Err() != nil || physicalSlotLimit(l) == 0 {
			continue
		}
		if available, ok := l.mail.(interface{ DataAvailable() bool }); ok && !available.DataAvailable() {
			continue
		}
		n++
		if best[0] == nil || l.account.ID < best[0].account.ID {
			best[1] = best[0]
			best[0] = l
		} else if best[1] == nil || l.account.ID < best[1].account.ID {
			best[1] = l
		}
	}
	if n < 5 {
		best = [2]*lane{}
	}
	return best
}
