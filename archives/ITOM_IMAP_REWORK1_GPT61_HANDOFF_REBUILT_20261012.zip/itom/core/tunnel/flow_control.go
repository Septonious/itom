package tunnel

import (
	"context"
	"errors"
	"time"

	"itom.local/core/wire"
)

type flowControlKey struct {
	kind   wire.Type
	stream uint64
}

// WINDOW and logical RECEIPT are cumulative. Keep only the newest unsent
// update per stream/type, before writer backpressure can fill the bounded
// channel with obsolete credit updates. No sealed/attempted record is replaced.
func (l *lane) enqueueFlowControl(ctx context.Context, item queuedControl) error {
	key := flowControlKey{item.Type, item.Stream}
	deadline := time.NewTimer(250 * time.Millisecond)
	defer deadline.Stop()
	for {
		l.flowControlMu.Lock()
		if l.flowControlLatest == nil {
			l.flowControlLatest = map[flowControlKey]queuedControl{}
		}
		if previous, found := l.flowControlLatest[key]; found {
			if item.Offset >= previous.Offset {
				item.added = previous.added
				l.flowControlLatest[key] = item
			}
			l.flowControlMu.Unlock()
			return nil
		}
		item.coalesced = true
		if len(l.flowControlLatest) < cap(l.controlQueue) {
			select {
			case l.controlQueue <- item:
				l.flowControlLatest[key] = item
				l.flowControlMu.Unlock()
				return nil
			default:
			}
		}
		l.flowControlMu.Unlock()
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-l.ctx.Done():
			return l.ctx.Err()
		case <-deadline.C:
			return errors.New("CONTROL_QUEUE_LIMIT")
		case <-time.After(time.Millisecond):
		}
	}
}

func (l *lane) resolveFlowControl(item queuedControl) queuedControl {
	if !item.coalesced {
		return item
	}
	key := flowControlKey{item.Type, item.Stream}
	l.flowControlMu.Lock()
	if latest, found := l.flowControlLatest[key]; found {
		item = latest
		delete(l.flowControlLatest, key)
	}
	l.flowControlMu.Unlock()
	item.coalesced = false
	return item
}

func coalesceCleanupStatus(batch []queuedControl, item queuedControl) []queuedControl {
	if item.Type != wire.GCStatus {
		return append(batch, item)
	}
	incoming, err := wire.DecodeControl(item.Frame)
	if err != nil {
		return append(batch, item)
	}
	next, ok := incoming.(wire.CleanupStatus)
	if !ok {
		return append(batch, item)
	}
	for i, old := range batch {
		if old.Type != wire.GCStatus {
			continue
		}
		decoded, err := wire.DecodeControl(old.Frame)
		if err != nil {
			continue
		}
		previous, ok := decoded.(wire.CleanupStatus)
		if !ok || previous.Key != next.Key {
			continue
		}
		dominates := func(a, b wire.CleanupStatus) bool {
			return a.Used.Bytes >= b.Used.Bytes && a.Used.Messages >= b.Used.Messages && a.Registered.Bytes >= b.Registered.Bytes && a.Registered.Messages >= b.Registered.Messages && a.Released.Bytes >= b.Released.Bytes && a.Released.Messages >= b.Released.Messages && (!b.Closed || a.Closed)
		}
		if dominates(next, previous) {
			item.added = old.added
			batch[i] = item
			return batch
		}
		if dominates(previous, next) {
			return batch
		}
	}
	return append(batch, item)
}
