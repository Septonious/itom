package tunnel

import "time"

// The modes describe useful delivery, not carrier connectivity. Outage never
// refunds an unknown physical APPEND or unacknowledged logical byte range.
type deliveryMode string

const (
	deliveryIdle      deliveryMode = "IDLE"
	deliveryNormal    deliveryMode = "NORMAL"
	deliveryProbeUp   deliveryMode = "PROBE_UP"
	deliveryCongested deliveryMode = "CONGESTED"
	deliveryOutage    deliveryMode = "OUTAGE"
	deliveryRecovery  deliveryMode = "RECOVERY"
)

type deliveryFeedback struct {
	Window, Flight, Delivered uint64
	Demand                    bool
	RateMbps                  float64
	Age, FastAge, Target      time.Duration
	Samples                   int
	Pressure                  bool
}

type deliveryPolicy struct {
	mode                       deliveryMode
	capacityMbps               float64
	lastProgress, lastProbe    time.Time
	delivered                  uint64
	healthy                    int
	probes, accepted, rejected uint64
}

func (p *deliveryPolicy) next(now time.Time, f deliveryFeedback) uint64 {
	window := f.Window
	if p.mode == "" {
		p.mode = deliveryNormal
	}
	if p.lastProgress.IsZero() || f.Delivered > p.delivered {
		p.lastProgress = now
	}
	progress := f.Delivered > p.delivered
	p.delivered = f.Delivered
	if !f.Demand && f.Flight == 0 {
		p.mode = deliveryIdle
		p.healthy = 0
		// Stale measured throughput must not pin the next burst. The retained
		// budget and durable ledgers are unchanged; fresh probes relearn capacity.
		p.capacityMbps = 0
		return window
	}
	if f.Flight > 0 && f.Age >= 3*time.Second && now.Sub(p.lastProgress) >= 3*time.Second {
		p.mode = deliveryOutage
		p.healthy = 0
		return max(uint64(deliveryMinWindow), window-window/4)
	}
	if f.Pressure || f.FastAge > deliveryFastMaxAge || f.Age > f.Target && (f.FastAge > 450*time.Millisecond || f.FastAge == 0 || !progress) {
		if p.mode == deliveryProbeUp {
			p.rejected++
		}
		p.mode = deliveryCongested
		p.healthy = 0
		p.lastProbe = now
		return max(uint64(deliveryMinWindow), window-window/8)
	}
	if !f.Demand {
		// Draining existing work is not a request for extra publication credit.
		return window
	}
	if p.mode == deliveryIdle {
		p.mode = deliveryNormal
	}
	// Use delivered application bytes. An application-limited/pacing-limited
	// low sample cannot ratchet the estimate down permanently.
	if f.RateMbps > 0 && (progress || f.Samples > 0) {
		if p.capacityMbps == 0 || f.RateMbps > p.capacityMbps {
			p.capacityMbps = f.RateMbps
		} else if f.Flight >= window/2 {
			p.capacityMbps = .875*p.capacityMbps + .125*f.RateMbps
		}
	}
	if p.mode == deliveryOutage || p.mode == deliveryCongested {
		p.mode = deliveryRecovery
	}
	if f.Samples == 0 && !progress {
		return window
	}
	p.healthy++
	if !p.lastProbe.IsZero() && now.Sub(p.lastProbe) < time.Second {
		return window
	}
	if p.healthy < 2 && p.mode == deliveryRecovery {
		return window
	}
	// Bounded probing is independent of a self-imposed pacing ceiling. A BDP
	// estimate is a starting point, never an excuse to exceed the latency guard.
	step := uint64(64 << 10)
	if p.capacityMbps >= 8 && f.Age < f.Target-100*time.Millisecond {
		bdp := uint64(p.capacityMbps * 1e6 / 8 * max(200*time.Millisecond, min(f.Age, f.Target)).Seconds())
		step = max(step, window/4)
		if bdp > window {
			step = min(window/2, max(step, bdp-window))
		}
	}
	if f.Age >= f.Target-100*time.Millisecond {
		// Plateau probes require fresh useful progress and hysteresis.
		if !progress || p.healthy < 3 {
			return window
		}
		step = 64 << 10
	}
	if p.mode == deliveryProbeUp {
		p.accepted++
	}
	p.mode = deliveryProbeUp
	p.probes++
	p.lastProbe = now
	if window >= deliveryMaxWindow {
		p.mode = deliveryNormal
	}
	return min(uint64(deliveryMaxWindow), window+step)
}
