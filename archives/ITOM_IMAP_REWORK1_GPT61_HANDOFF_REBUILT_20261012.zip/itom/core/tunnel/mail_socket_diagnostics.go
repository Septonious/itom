package tunnel

import "itom.local/core/mailbox"

// Snapshot actual physical workers, including the account DATA workers shared
// by server users. Role+socket ID avoids attributing an idle EOF to a lane index.
func (m *laneMail) SocketSnapshots() []mailbox.SocketSnapshot {
	out := []mailbox.SocketSnapshot{m.Client.SocketSnapshot("control")}
	if reader := m.readerRef(); reader != nil && reader != m.Client {
		out = append(out, reader.SocketSnapshot("receive"))
	}
	if previous := m.previousReader.Load(); previous != nil {
		out = append(out, *previous)
	}
	m.cleanerMu.Lock()
	cleaner := m.cleaner
	m.cleanerMu.Unlock()
	if cleaner != nil && cleaner != m.Client {
		out = append(out, cleaner.SocketSnapshot("maintenance"))
	}
	m.writerMu.Lock()
	writers := append([]*mailbox.Client(nil), m.writers...)
	m.writerMu.Unlock()
	for id, c := range writers {
		if c != nil {
			state := c.SocketSnapshot("data")
			state.WorkerID = id
			out = append(out, state)
		}
	}
	if m.runtime != nil {
		m.runtime.mu.Lock()
		type worker struct {
			id     int
			client appendClient
		}
		clients := make([]worker, 0, len(m.runtime.workerSockets))
		for id, c := range m.runtime.workerSockets {
			clients = append(clients, worker{id, c})
		}
		m.runtime.mu.Unlock()
		for _, c := range clients {
			if client, ok := c.client.(*mailbox.Client); ok {
				state := client.SocketSnapshot("shared_data")
				state.WorkerID = c.id
				out = append(out, state)
			}
		}
	}
	return out
}
