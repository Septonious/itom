package manager

import (
	"context"
	"errors"
	"fmt"
	"itom.local/core/mailbox"
	"itom.local/core/servercfg"
	"strings"
	"time"
)

type accountAdmin interface {
	Folders(context.Context) ([]mailbox.Folder, error)
	PurgeAll(context.Context) (mailbox.PurgeReport, error)
	Close() error
}

func (u *UI) accountMaintenance(cfg servercfg.Config, choice string) error {
	id, err := u.ask("Email аккаунта")
	if err != nil {
		return err
	}
	var target servercfg.Account
	for _, a := range cfg.Accounts {
		if strings.EqualFold(a.Mail.Username, id) {
			target = a
			break
		}
	}
	if target.ID == "" {
		return errors.New("аккаунт не найден")
	}
	fmt.Fprintf(u.Out, "Аккаунт %s на %q\n", target.Mail.Username, target.Mail.Host)
	if choice == "3" {
		fmt.Fprintln(u.Out, "Удаляется подключение из ITOM. Почтовый ящик у провайдера и письма сохраняются. Журналы незавершённых записей сохраняются. Отключите VPN на клиентах и после удаления экспортируйте обновлённые профили.")
		if err = u.stopped(); err != nil {
			return err
		}
		err = servercfg.Update(u.db(), func(c *servercfg.Config) error {
			for _, a := range c.Accounts {
				if strings.EqualFold(a.Mail.Username, id) && a != target {
					return errors.New("конфигурация аккаунта изменилась; повторите выбор")
				}
			}
			return c.RemoveAccount(target.ID)
		})
		if err == nil {
			fmt.Fprintln(u.Out, "Аккаунт удалён из ITOM. Экспортируйте профили заново (пункт 5).")
		}
		return err
	}
	fmt.Fprintln(u.Out, "Будут безвозвратно удалены ВСЕ доступные папки и письма этого аккаунта, включая не-ITOM. INBOX и папки, удаление которых запрещено сервером, будут очищены. Остановите все клиенты этого аккаунта; другие аккаунты не затрагиваются.")
	ctx, cancel := context.WithTimeout(context.Background(), 12*time.Minute)
	defer cancel()
	dial := u.adminDial
	if dial == nil {
		dial = func(ctx context.Context, cfg mailbox.Config) (accountAdmin, error) {
			return mailbox.DialAdmin(ctx, cfg)
		}
	}
	admin, err := dial(ctx, target.Mail)
	if err != nil {
		return err
	}
	defer admin.Close()
	folders, err := admin.Folders(ctx)
	if err != nil {
		return err
	}
	fmt.Fprintf(u.Out, "Найдено папок: %d\n", len(folders))
	for _, f := range folders {
		fmt.Fprintf(u.Out, "  %q\n", f.Name)
	}
	if err = u.stopped(); err != nil {
		return err
	}
	current, err := servercfg.Load(u.db())
	if err != nil {
		return err
	}
	unchanged := false
	for _, a := range current.Accounts {
		if a == target {
			unchanged = true
		}
	}
	if !unchanged {
		return errors.New("конфигурация аккаунта изменилась; повторите выбор")
	}
	fmt.Fprintln(u.Out, "Очистка выполняется…")
	report, err := admin.PurgeAll(ctx)
	labels := map[string]string{"DELETED": "папка удалена", "KEPT_EMPTY": "папка сохранена и очищена", "NOT_EMPTIED": "очистка не подтверждена", "UNKNOWN": "результат не подтверждён", "UNSUBSCRIBE_REFUSED": "подписку удалить не удалось"}
	for _, item := range report.Items {
		fmt.Fprintf(u.Out, "%q — %s\n", item.Name, labels[item.Outcome])
	}
	if report.Verified {
		fmt.Fprintln(u.Out, "Проверка завершена. Оставшиеся папки:")
		for _, name := range report.Remaining {
			fmt.Fprintf(u.Out, "  %q\n", name)
		}
	} else {
		fmt.Fprintln(u.Out, "Полная очистка не подтверждена. Возможен частичный результат; список папок можно проверить повторным входом в этот пункт.")
	}
	fmt.Fprintln(u.Out, "Конфигурация и журналы ITOM сохранены. При запуске нужные папки будут созданы заново; очистка не сбрасывает неопределённые квоты.")
	return err
}

func (u *UI) waitAdmin(ctx context.Context, d time.Duration) error {
	if u.pauseAdmin != nil {
		return u.pauseAdmin(ctx, d)
	}
	t := time.NewTimer(d)
	defer t.Stop()
	select {
	case <-ctx.Done():
		return ctx.Err()
	case <-t.C:
		return nil
	}
}

// purgeAllAccounts is deliberately serial. It never opens two destructive
// admin connections at once and inserts a cool-down between accounts so a
// provider does not see a burst of DELETE/EXPUNGE operations from ITOM.
func (u *UI) purgeAllAccounts(cfg servercfg.Config) error {
	if len(cfg.Accounts) == 0 {
		return errors.New("нет почтовых аккаунтов")
	}
	fmt.Fprintln(u.Out, "ПОЛНАЯ ОЧИСТКА: будут удалены все доступные письма и пользовательские папки во ВСЕХ настроенных почтовых аккаунтах. Системные папки, которые провайдер запрещает удалить, будут очищены. Операция выполняется строго последовательно и с паузами.")
	var failures []string
	for i, account := range cfg.Accounts {
		if i > 0 {
			ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
			err := u.waitAdmin(ctx, 2*time.Second)
			cancel()
			if err != nil {
				return err
			}
		}
		fmt.Fprintf(u.Out, "\n[%d/%d] %s — начало очистки\n", i+1, len(cfg.Accounts), account.Mail.Username)
		ctx, cancel := context.WithTimeout(context.Background(), 15*time.Minute)
		dial := u.adminDial
		if dial == nil {
			dial = func(ctx context.Context, cfg mailbox.Config) (accountAdmin, error) {
				return mailbox.DialAdmin(ctx, cfg)
			}
		}
		admin, err := dial(ctx, account.Mail)
		if err != nil {
			cancel()
			failures = append(failures, account.Mail.Username+": "+err.Error())
			fmt.Fprintf(u.Out, "%s — ошибка подключения: %v\n", account.Mail.Username, err)
			continue
		}
		report, purgeErr := admin.PurgeAll(ctx)
		closeErr := admin.Close()
		cancel()
		for _, item := range report.Items {
			fmt.Fprintf(u.Out, "%s | %q — %s\n", account.Mail.Username, item.Name, item.Outcome)
		}
		if purgeErr == nil && closeErr == nil && report.Verified {
			fmt.Fprintf(u.Out, "%s — очистка подтверждена\n", account.Mail.Username)
			continue
		}
		if purgeErr == nil {
			purgeErr = closeErr
		}
		if purgeErr == nil {
			purgeErr = errors.New("IMAP_PURGE_INCOMPLETE")
		}
		failures = append(failures, account.Mail.Username+": "+purgeErr.Error())
		fmt.Fprintf(u.Out, "%s — очистка не подтверждена: %v\n", account.Mail.Username, purgeErr)
	}
	if len(failures) != 0 {
		return fmt.Errorf("полная очистка завершена с ошибками: %s", strings.Join(failures, "; "))
	}
	fmt.Fprintln(u.Out, "\nВсе почтовые аккаунты очищены последовательно. Конфигурация ITOM и журналы physical debt не удалялись.")
	return nil
}
