package manager

import (
	"context"
	"errors"
	"fmt"
	"os"
	"os/exec"
	"os/signal"
	"runtime"
)

func liveLogCommand(ctx context.Context) *exec.Cmd {
	return exec.CommandContext(ctx, "journalctl", "--unit=itom.service", "--follow", "--lines=0", "--no-pager", "--output=short-iso")
}
func (u *UI) followLogs() error {
	if runtime.GOOS != "linux" {
		return errors.New("логи службы доступны на Linux с systemd")
	}
	fmt.Fprintln(u.Out, "Логи ITOM в реальном времени. Ctrl+C — вернуться в меню; служба продолжит работу.")
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt)
	defer stop()
	cmd := liveLogCommand(ctx)
	cmd.Stdout = u.Out
	cmd.Stderr = u.Out
	err := cmd.Run()
	if ctx.Err() != nil {
		fmt.Fprintln(u.Out, "\nПросмотр логов завершён.")
		return nil
	}
	return err
}
