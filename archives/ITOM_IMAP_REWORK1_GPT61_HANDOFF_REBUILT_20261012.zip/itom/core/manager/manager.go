package manager

import (
	"bufio"
	"context"
	"errors"
	"fmt"
	"io"
	"itom.local/core/mailbox"
	"itom.local/core/servercfg"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strconv"
	"strings"
	"time"
)

type UI struct {
	In           *bufio.Reader
	Out          io.Writer
	State        string
	Secret       func() (string, error)
	stoppedCheck func() error
	adminDial    func(context.Context, mailbox.Config) (accountAdmin, error)
	pauseAdmin   func(context.Context, time.Duration) error
}

func New(state string) *UI { return &UI{In: bufio.NewReader(os.Stdin), Out: os.Stdout, State: state} }
func (u *UI) ask(label string) (string, error) {
	fmt.Fprint(u.Out, label+": ")
	s, e := u.In.ReadString('\n')
	if e != nil {
		return "", e
	}
	if len(s) > 4096 {
		return "", errors.New("INPUT_LIMIT")
	}
	return strings.TrimSpace(s), nil
}
func (u *UI) password() (string, error) {
	if u.Secret != nil {
		return u.Secret()
	}
	fmt.Fprint(u.Out, "Пароль приложения IMAP: ")
	value, err := u.In.ReadString('\n')
	if err != nil {
		return "", err
	}
	value = strings.TrimSuffix(strings.TrimSuffix(value, "\n"), "\r")
	if len(value) > 4096 {
		return "", errors.New("INPUT_LIMIT")
	}
	return value, nil
}
func (u *UI) db() string { return filepath.Join(u.State, "server.db") }
func (u *UI) system(action string) error {
	if runtime.GOOS != "linux" {
		return errors.New("служба доступна на Linux с systemd")
	}
	c := exec.Command("systemctl", action, "itom.service")
	c.Stdout = u.Out
	c.Stderr = u.Out
	return c.Run()
}
func (u *UI) stopped() error {
	if u.stoppedCheck != nil {
		return u.stoppedCheck()
	}
	if runtime.GOOS == "linux" {
		out, err := exec.Command("systemctl", "is-active", "itom.service").Output()
		state := strings.TrimSpace(string(out))
		var exit *exec.ExitError
		if errors.As(err, &exit) && (exit.ExitCode() == 3 || exit.ExitCode() == 4) && (state == "inactive" || state == "failed" || state == "unknown") {
			return nil
		}
		if err != nil && state == "" {
			return errors.New("не удалось проверить состояние systemd; операция отменена")
		}
		return errors.New("сначала остановите службу пунктом 8; после изменений запустите пунктом 7")
	}
	return nil
}
func (u *UI) Run() error {
	if e := os.MkdirAll(u.State, 0700); e != nil {
		return e
	}
	for {
		fmt.Fprintln(u.Out, "\nITOM — менеджер сервера\nРежим: зашифрованный IMAP-транспорт для Android VPN.\n1. Состояние\n2. Инициализировать сервер\n3. Почтовые аккаунты\n4. Пользователи\n5. Экспорт профиля Android\n6. Проверить IMAP аккаунты\n7. Запустить службу\n8. Остановить службу\n9. Перезапустить службу\n10. Логи в реальном времени\n11. Установить/обновить службу\n12. Трассировка пакетов в реальном времени\n13. Экспорт полной диагностики\n0. Выход")
		s, e := u.ask("Выбор")
		if e == io.EOF {
			return nil
		}
		if e != nil {
			return e
		}
		switch s {
		case "0":
			return nil
		case "1":
			e = u.status()
		case "2":
			e = u.init()
		case "3":
			e = u.accounts()
		case "4":
			e = u.users()
		case "5":
			e = u.export()
		case "6":
			e = u.check()
		case "7":
			e = u.system("start")
		case "8":
			e = u.system("stop")
		case "9":
			e = u.system("restart")
		case "10":
			e = u.followLogs()
		case "11":
			e = Install()
		case "12":
			e = u.followTrace()
		case "13":
			e = u.exportTrace()
		default:
			fmt.Fprintln(u.Out, "Введите номер пункта.")
		}
		if e != nil {
			fmt.Fprintln(u.Out, "Ошибка:", e)
		}
	}
}
func (u *UI) status() error {
	c, e := servercfg.Load(u.db())
	if e != nil {
		return e
	}
	fmt.Fprintf(u.Out, "Провайдер: %s; аккаунтов: %d/10; пользователей: %d/2\n", c.Provider, len(c.Accounts), len(c.Users))
	for _, x := range c.Users {
		fmt.Fprintf(u.Out, "UID %s | %s | включён=%t\n", x.ID, x.Name, x.Enabled)
	}
	if runtime.GOOS == "linux" {
		return u.system("status")
	}
	return nil
}
func (u *UI) init() error {
	if e := u.stopped(); e != nil {
		return e
	}
	if _, e := servercfg.Load(u.db()); e == nil {
		return errors.New("сервер уже создан; данные не перезаписаны")
	}
	name, e := u.ask("Название почтового провайдера")
	if e != nil {
		return e
	}
	return servercfg.Update(u.db(), func(c *servercfg.Config) error {
		if c.Schema != 0 {
			return errors.New("уже создан")
		}
		n, e := servercfg.New(name)
		*c = n
		return e
	})
}
func (u *UI) accounts() error {
	c, e := servercfg.Load(u.db())
	if e != nil {
		return e
	}
	for _, a := range c.Accounts {
		fmt.Fprintf(u.Out, "%s | %s:%d %s\n", a.Mail.Username, a.Mail.Host, a.Mail.Port, a.Mail.TLS)
	}
	choice, e := u.ask("1 добавить, 2 изменить пароль, 3 удалить аккаунт из ITOM, 4 удалить все папки и письма аккаунта, 5 полностью очистить ВСЕ почтовые аккаунты, 0 назад")
	if e != nil || choice == "0" {
		return e
	}
	if e = u.stopped(); e != nil {
		return e
	}
	if choice == "3" || choice == "4" {
		return u.accountMaintenance(c, choice)
	}
	if choice == "5" {
		return u.purgeAllAccounts(c)
	}
	if choice == "2" {
		id, e := u.ask("Email аккаунта")
		if e != nil {
			return e
		}
		password, e := u.password()
		if e != nil {
			return e
		}
		return servercfg.Update(u.db(), func(c *servercfg.Config) error {
			for i := range c.Accounts {
				if strings.EqualFold(c.Accounts[i].Mail.Username, id) {
					c.Accounts[i].Mail.Password = password
					return nil
				}
			}
			return errors.New("аккаунт не найден")
		})
	}
	if choice != "1" {
		return errors.New("неизвестный пункт")
	}
	if len(c.Accounts) >= 10 {
		return errors.New("достигнут лимит 10 аккаунтов")
	}
	var cfg mailbox.Config
	if len(c.Accounts) > 0 {
		cfg = c.Accounts[0].Mail
		cfg.Password = ""
		cfg.Username = ""
	} else {
		cfg.Host, e = u.ask("IMAP hostname")
		if e != nil {
			return e
		}
		mode, e := u.ask("1 IMAPS/TLS (993), 2 обязательный STARTTLS (143)")
		if e != nil {
			return e
		}
		cfg.TLS = "tls"
		cfg.Port = 993
		if mode == "2" {
			cfg.TLS = "starttls"
			cfg.Port = 143
		} else if mode != "1" {
			return errors.New("неизвестный режим")
		}
		port, e := u.ask(fmt.Sprintf("Порт (Enter = %d)", cfg.Port))
		if e != nil {
			return e
		}
		if port != "" {
			cfg.Port, e = strconv.Atoi(port)
			if e != nil {
				return e
			}
		}
	}
	cfg.Username, e = u.ask("Логин")
	if e != nil {
		return e
	}
	cfg.Password, e = u.password()
	if e != nil {
		return e
	}
	if e = cfg.Validate(); e != nil {
		return e
	}
	return servercfg.Update(u.db(), func(c *servercfg.Config) error {
		_, err := c.AddAccount(cfg)
		return err
	})
}
func (u *UI) users() error {
	c, e := servercfg.Load(u.db())
	if e != nil {
		return e
	}
	for _, x := range c.Users {
		fmt.Fprintf(u.Out, "%s | %s | включён=%t\n", x.ID, x.Name, x.Enabled)
	}
	choice, e := u.ask("1 добавить, 2 переименовать, 3 включить/отключить, 0 назад")
	if e != nil || choice == "0" {
		return e
	}
	if e = u.stopped(); e != nil {
		return e
	}
	if choice == "1" {
		name, e := u.ask("Имя пользователя")
		if e != nil {
			return e
		}
		var uid string
		e = servercfg.Update(u.db(), func(c *servercfg.Config) error { x, err := c.AddUser(name); uid = x.ID; return err })
		if e == nil {
			fmt.Fprintln(u.Out, "Создан UID", uid)
		}
		return e
	}
	if choice != "2" && choice != "3" {
		return errors.New("неизвестный пункт")
	}
	id, e := u.ask("UID")
	if e != nil {
		return e
	}
	name := ""
	if choice == "2" {
		name, e = u.ask("Новое имя")
		if e != nil {
			return e
		}
	}
	return servercfg.Update(u.db(), func(c *servercfg.Config) error {
		for i := range c.Users {
			if c.Users[i].ID == id {
				if choice == "2" {
					c.Users[i].Name = name
				} else {
					c.Users[i].Enabled = !c.Users[i].Enabled
				}
				return nil
			}
		}
		return errors.New("UID не найден")
	})
}
func (u *UI) export() error {
	c, e := servercfg.Load(u.db())
	if e != nil {
		return e
	}
	uid, e := u.ask("UID")
	if e != nil {
		return e
	}
	link, e := c.AndroidLink(uid)
	if e != nil {
		return e
	}
	fmt.Fprintln(u.Out, link)

	return nil
}
func (u *UI) check() error {
	if e := u.stopped(); e != nil {
		return e
	}
	c, e := servercfg.Load(u.db())
	if e != nil {
		return e
	}
	if len(c.Users) == 0 {
		return errors.New("сначала добавьте пользователя")
	}
	folders := []string{c.Users[0].Up, c.Users[0].Down}
	for _, a := range c.Accounts {
		ctx, stop := context.WithTimeout(context.Background(), 45*time.Second)
		cli, e := mailbox.Dial(ctx, a.Mail, folders)
		if e == nil {
			for _, f := range folders {
				if e = cli.Ensure(ctx, f); e != nil {
					break
				}
			}
			cli.Close()
		}
		stop()
		if e != nil {
			fmt.Fprintf(u.Out, "%s: %v\n", a.Mail.Username, e)
		} else {
			fmt.Fprintf(u.Out, "%s: TLS / LOGIN / папки OK\n", a.Mail.Username)
		}
	}
	return nil
}

const unit = `[Unit]
Description=ITOM encrypted IMAP TCP transport
After=network-online.target
Wants=network-online.target
[Service]
Type=simple
ExecStart=/usr/local/bin/itom serve --state /var/lib/itom
Restart=on-failure
RestartSec=10
TimeoutStopSec=45
UMask=0077
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=/var/lib/itom
[Install]
WantedBy=multi-user.target
`

// Install copies the manually supplied running binary atomically, preserving
// /var/lib/itom. An active service is restarted, with binary rollback on failure.
func Install() error {
	if runtime.GOOS != "linux" || os.Geteuid() != 0 {
		return errors.New("установка: Linux, sudo и systemd")
	}
	if _, e := exec.LookPath("systemctl"); e != nil {
		return e
	}
	if e := os.MkdirAll("/var/lib/itom", 0700); e != nil {
		return e
	}
	src, e := os.Executable()
	if e != nil {
		return e
	}
	dst := "/usr/local/bin/itom"
	wasActive := exec.Command("systemctl", "is-active", "--quiet", "itom.service").Run() == nil
	old, e := os.ReadFile(dst)
	hadOld := e == nil
	if e != nil && !os.IsNotExist(e) {
		return e
	}
	data, e := os.ReadFile(src)
	if e != nil {
		return e
	}
	if len(data) > 100<<20 {
		return errors.New("binary exceeds limit")
	}
	unitPath := "/etc/systemd/system/itom.service"
	oldUnit, ue := os.ReadFile(unitPath)
	if ue != nil && !os.IsNotExist(ue) {
		return ue
	}
	if e = atomicFile(dst, data, 0755); e != nil {
		return e
	}
	rollback := func() {
		if hadOld {
			_ = atomicFile(dst, old, 0755)
		}
		if ue == nil {
			_ = atomicFile(unitPath, oldUnit, 0644)
		}
		_ = exec.Command("systemctl", "daemon-reload").Run()
		if wasActive {
			_ = exec.Command("systemctl", "restart", "itom.service").Run()
		}
	}
	if e = atomicFile(unitPath, []byte(unit), 0644); e != nil {
		rollback()
		return e
	}
	if e = exec.Command("systemctl", "daemon-reload").Run(); e != nil {
		rollback()
		return e
	}
	if e = exec.Command("systemctl", "enable", "itom.service").Run(); e != nil {
		rollback()
		return e
	}
	if wasActive {
		if e = exec.Command("systemctl", "restart", "itom.service").Run(); e == nil {
			time.Sleep(500 * time.Millisecond)
			e = exec.Command("systemctl", "is-active", "--quiet", "itom.service").Run()
		}
		if e != nil {
			rollback()
			return errors.New("restart failed; previous binary restored")
		}
	}
	fmt.Println("ITOM установлен. Команда меню: sudo itom. Конфигурация сохранена.")
	return nil
}
func atomicFile(path string, data []byte, mode os.FileMode) error {
	f, e := os.CreateTemp(filepath.Dir(path), ".itom-install-")
	if e != nil {
		return e
	}
	name := f.Name()
	defer os.Remove(name)
	if e = f.Chmod(mode); e == nil {
		_, e = f.Write(data)
	}
	if e == nil {
		e = f.Sync()
	}
	ce := f.Close()
	if e != nil {
		return e
	}
	if ce != nil {
		return ce
	}
	if e = os.Rename(name, path); e != nil {
		return e
	}
	d, e := os.Open(filepath.Dir(path))
	if e != nil {
		return e
	}
	defer d.Close()
	return d.Sync()
}
