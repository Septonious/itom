package mailbox

// InterruptReceive closes only this generation without waiting for its command
// mutex. The receive owner joins the command before replacement.
func (c *Client) InterruptReceive() {
	if c == nil || c.conn == nil {
		return
	}
	c.conn.noteClose("receive", "no_progress")
	c.closed.Store(true)
	_ = c.conn.Close()
}
