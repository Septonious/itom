# ITOM FIELD72 — 30/30 Mbit/s validation candidate (not field-qualified)

Transport code is based on the restored FIELD68 development baseline. This candidate
keeps the hard 24 upload + 24 download TCP acceptance gate: 30 Mbit/s both ways,
30 seconds after warm-up, every echo RTT <800 ms, zero timeouts and no 5s stalls.
The previous real-provider field failure of FIELD67 is **not** proven resolved.

## One build command (Windows PowerShell, in folder containing the source ZIP)

```powershell
python .\ITOM_TRANSPORT_FIELD72_SOURCE.zip all --expect-revision transport-s1-perf7-field72 --accept-android-licenses
```

On success, the ZIP launcher now publishes verified APK and Linux binaries to
`dist/` **next to the source ZIP** (also prints their absolute paths). If Gradle
SDK, Kotlin, lint, domain tests or Go gate fail, no new APK is exported.
The extracted directory has its own internal `itom/dist` build logs.

## Server update after copying the amd64 binary to VPS /tmp

```bash
sudo install -m 755 /tmp/ITOM_FIELD72_linux_amd64 /usr/local/bin/itom-field72 && sudo /usr/local/bin/itom-field72 install
```

Check that the server reports `transport-s1-perf7-field72` before use. Backup
`/var/lib/itom` and all durable state; do not overwrite a live FIELD67 journal
with different physical BINARY DATA representations without verified migration.

## Standalone performance gate (on a machine with Go 1.27.1)

```bash
python tools/run_speedtest_gate.py --profile normal --streams 24 --seconds 30 --warmup 10
```

The source package does not include a pre-built Android APK. An actual SDK build
and real provider tests are required before production deployment.
