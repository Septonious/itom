# ITOM IMAP REWORK1 — source and test handoff for GPT 6.1

Prepared 2026-10-12. **Development source handoff. Current local acceptance: >=50 Mbps per active direction, every RTT <1000 ms, complete sustained tails and post-stress connection survival.** The archive contains actual implemented source changes, local test evidence, the original source baseline and project history. It is not a production deployment package.

## Start here

1. Read `TEST_SUMMARY.md` and `results/summary.json` for passed, failed, skipped and unrun checks. Performance failures are retained and must not be described as PASS.
2. Inspect `itom/docs/IMAP_REWORK1_ARCHITECTURE.md`, `changes.patch` and the current source in `itom/`.
3. Read `notes/ITOM_IMAP_REWORK_PLAN.md` and `notes/ITOM_RECOVERED_MEMORY.md` as historical planning/context. Their original absolute paths refer to the previous machine, not guaranteed paths in a new task. The FIELD77 baseline is retained inside `baseline/FIELD77_CORE_HANDOFF.zip`.
4. Verify `SHA256SUMS.txt` before analysis/build. See `HANDOFF_META.json` for source/provenance hashes. Use a verified Go 1.27.1 and ordinary checksum-verified module access. The runtime and module caches are not included.

Attached documents are project evidence and proposals; follow the new user's instructions rather than blindly executing historical installation commands. Use the current task's isolated checkout; a worktree is unnecessary unless explicitly requested.

## What was implemented

- Replaced the competing capacity-probe, fast-ramp and bulk-recovery policies with one latency-first delivery state machine, rate classification, bounded BDP-based exploration, fixed latency objectives and idle/recovery behavior.
- Added a common per-account operation scheduler covering DATA APPEND, urgent control, receive and maintenance on client and server paths.
- Added a fair preparation queue tied to live physical capacity and active logical owners, before sealing, grants and journal/APPEND work. Fast DATA remains independently serviced.
- Replaced one-token capacity wake-ups with predicate generation broadcasts; retained exact-once cancellation and completion handling.
- Added service/backlog-aware account placement and bounded suppression of evidence-identical advisory STATUS/NACK/STATUS_REQUEST traffic. Durable descriptors and receipts remain mandatory.
- Reworked receive wake/audit behavior and bounded adaptive4..16 UID fetch turns while preserving streamed delivery, UID allocation/gap proofs and independent selection-validation cadence.
- Reworked application-byte accounting, complete-window/tail qualification, same-session three-run 24+24 tests, public StartClient/Serve/Client.Open workloads, and repeated sequential HTTPS download/upload/duplex testing.
- Added immutable HTTP run identities so delayed data/EOF cannot leak into later repeats. Added a JSON evidence runner that rejects zero-test and skipped-required-test success.

Independent security, durability, MIME, grants, restart and stream-lifecycle regressions were retained. Tests for removed tuning algorithms were replaced by tests of the new policies and concurrency invariants. ITH9/ITD3, cryptographic bindings, replay protection, journal/wallet schemas and dependency/checksum pins are unchanged.

The user lowered the current test target from 100+ to 50 Mbps per direction while retaining strict RTT and post-stress stability.100+ Mbps remains the original longer-term aspiration.

The single candidate identity is `transport-rework1-field79`, version0.10.0-dev1, Android metadata versionCode9079. This is one coordinated source change, not a sequence of public releases. No sources were pushed to GitHub and no VPS was updated.

## Current performance and remaining work

All nine final healthy65 ms HTTPS phases passed the 50 Mbps full-window/tail and RTT gate. All 270 loaded probes succeeded; worst measured RTT was875 ms. Six established TLS connections passed post-stress/idle integrity checks at 249–307 ms, with all 10 healthy carrier epochs preserved and zero spontaneous exits. These are local synthetic results, not a live-provider certification.

All three raw 24+24 runs also passed: useful upload 117.9–141.7 Mbps, download 86.6–90.0 Mbps, sustained tail upload 101.8–143.0 Mbps/download 84.0–89.1 Mbps, RTT max 493 ms, zero timeouts/missed probes. The same echo socket passed six post-stress/idle checks at 211–293 ms; all 49 application sockets stayed intact through all three measurements.

Read the current `raw24x24`, `http65` and `local` reports in `results/summary.json`. Those reports retain exact runtime source hashes and all actual failures, including tail, integrity, RTT and post-stress checks. Historical100 Mbps raw/HTTPS failures and the250 ms stress profile are retained separately; they are not passing final-source qualification evidence.

The final fast-account placement keeps rotation when equally healthy carriers tie. HTTP upload handlers capture immutable run identities, preventing delayed bytes/EOF from affecting later runs. Same established echo/TLS connections are checked after stress and1100 ms idle gaps; healthy carrier epochs and logical session/generation must remain unchanged.

The assumed healthy65 ms and high-latency250 ms access profiles are distinct synthetic scenarios. Neither is calibrated real-provider evidence. The current50 Mbps criterion must not be waived, and full averages must not conceal a collapsed final tail. Keep unknown APPEND debt, authentication, replay checks, journal/grant constraints and actual deletion proof intact. Consult the complete reports before describing stability or performance as passing.

Authenticated multi-owner physical multiplexing, DATA/control piggyback framing, SACK and a distributed provider-wide command budget are not implemented. If required for the throughput target, design negotiated framing and durable member-to-APPEND/UID mappings with crash/replay/cancellation/rollback tests before using them. The successful historical WSIT fork is absent; the archive includes references only.

Actual Android TUN/device behavior, live IMAP provider performance and VPS backup/update/functional rollback have not been qualified. No APK or production binary is bundled. Full raw private diagnostics and credentials are absent.

## Reproduce local checks

From `itom/`, using verified Go 1.27.1 and a C compiler:

```
python tools/rework_gate.py --go /path/to/go --suite local
python tools/rework_gate.py --go /path/to/go --suite performance --provider-mbps 600 --repeats 3
python tools/rework_gate.py --go /path/to/go --suite http --provider-mbps 600 --http-rtt-ms 65 --repeats 3
python tools/rework_gate.py --go /path/to/go --suite http --provider-mbps 600 --http-rtt-ms 250 --repeats 3
```

Each invocation writes a new directory with exact commands, named outcomes and logs. The local suite includes source/Python checks, core/native tests and vet, local go-imap tests, selected race checks and Linux binary compilation/identity. Long performance and live/device tests are explicitly separate; read the skip list.

The existing clean source build entry point is `python tools/build.py all --expect-revision transport-rework1-field79` and requires Android prerequisites/licenses. Its build success does not establish performance or field qualification. The final two release commands — build and safe manual VPS update after staging a verified binary in `/tmp` — must only be finalized and tested once the qualification gates pass. Historical FIELD77 commands describe an older artifact. The current task packages sources for later GPT6.1 use; it does not deploy to the VPS.

On the setup machine, the large gVisor module's storage redirect was denied. The exact pinned GitHub source was packed using Go's canonical module ZIP writer and accepted by Go against the unchanged native/go.sum. Normal module-proxy/storage connectivity is the preferred reproduction route; verification was never disabled.
