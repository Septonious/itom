# Local test and performance evidence

This source is a development handoff. Functional local checks passed; the current acceptance threshold is 50 Mbps in each direction, every RTT strictly below 1000 ms, sustained tails and post-stress connection survival. Android/device, real-provider and VPS deployment checks were not run.

## Final local checks

| Check | Result | Named test outcomes (includes subtests) | Skipped |
|---|---|---:|---:|
| source | PASS | 0 | 0 |
| core | PASS | 604 | 7 |
| vet-core | PASS | 0 | 0 |
| native | PASS | 2 | 0 |
| vet-native | PASS | 0 | 0 |
| imap-fork | PASS | 70 | 1 |
| race-durable | PASS | 246 | 0 |
| race-transport | PASS | 38 | 0 |
| build-linux | PASS | 0 | 0 |
| binary-identity | PASS | 0 | 0 |

Required/selected named tests executed; zero-test and skipped-required-test checks are rejected by the runner. Optional long performance tests and Dovecot integration may be skipped in the local suite; exact names are in results/local/results.json. Race checks are selected suites, not an exhaustive device/field race certification.

## Current 50 Mbps synthetic acceptance

| Run | Upload Mbps | Download Mbps | Tail UL Mbps | Tail DL Mbps | Max RTT ms |
|---|---:|---:|---:|---:|---:|
| Raw24+24 repeat1 | 141.715 | 88.238 | 143.000 | 89.129 | 329 |
| Raw24+24 repeat2 | 117.851 | 90.046 | 101.817 | 89.129 | 493 |
| Raw24+24 repeat3 | 139.399 | 86.595 | 128.057 | 84.043 | 357 |

Final HTTPS: all 9 download/upload/duplex phases passed. Every active full-window rate was at least 74.161 Mbps; every active tail was at least 61.761 Mbps; all 270 loaded probes succeeded and worst RTT was 875 ms. Six established TLS connections survived post-stress idle checks, with 10 carrier epochs preserved and zero spontaneous exits. Raw post-stress echo also passed 6 verified exchanges with RTT 211–293 ms. These values describe the declared synthetic 600 Mbps physical profile, not a measured live provider.

## Preserved prior performance evidence

The raw 24+24 test uses 600 Mbps physical capacity, 10 accounts, 65 ms command delays, three full 30 s measurements on one live session. Each must deliver 50 Mbps in both directions and sustain the tail with application RTT<1000 ms. Its exact acceptance outcome and post-stress evidence are recorded below. Earlier 100 Mbps failures are retained as historical investigation evidence.

HTTPS 65 and 250 ms access profiles are distinct. The 250 ms run is retained as failed stress evidence from the earlier harness; repeat/cancellation isolation was fixed afterwards and verified independently. It is not claimed to be a final-source qualification run. The current healthy 65 ms run tests the corrected harness and final source. The prior100_http report includes the earlier third-download-tail collapse; do not relabel historical failures as passing.

- raw24x24: `supervised_load_test.go:252: supervised_result round=1 measured_ms=30000 upload_mbps=141.715 download_mbps=88.238 rtt_samples=30 p50_ms=259 p95_ms=327 max_ms=329 timeouts=0 missed=0 overlap=30 failure=<nil>`
- raw24x24: `supervised_load_test.go:253: supervised_carriers healthy=10 spontaneous_outages=0 epochs_preserved=true`
- raw24x24: `supervised_load_test.go:305: supervised_acceptance round=1 tier=50_mbps_lt1000ms minimum_verified_mbps=88.237670 max_rtt_ns=329667172 accepted=true field_qualified=false`
- raw24x24: `supervised_load_test.go:252: supervised_result round=2 measured_ms=30000 upload_mbps=117.851 download_mbps=90.046 rtt_samples=30 p50_ms=260 p95_ms=316 max_ms=493 timeouts=0 missed=0 overlap=30 failure=<nil>`
- raw24x24: `supervised_load_test.go:253: supervised_carriers healthy=10 spontaneous_outages=0 epochs_preserved=true`
- raw24x24: `supervised_load_test.go:305: supervised_acceptance round=2 tier=50_mbps_lt1000ms minimum_verified_mbps=90.046464 max_rtt_ns=493183314 accepted=true field_qualified=false`
- raw24x24: `supervised_load_test.go:252: supervised_result round=3 measured_ms=30000 upload_mbps=139.399 download_mbps=86.595 rtt_samples=30 p50_ms=274 p95_ms=332 max_ms=357 timeouts=0 missed=0 overlap=30 failure=<nil>`
- raw24x24: `supervised_load_test.go:253: supervised_carriers healthy=10 spontaneous_outages=0 epochs_preserved=true`
- raw24x24: `supervised_load_test.go:305: supervised_acceptance round=3 tier=50_mbps_lt1000ms minimum_verified_mbps=86.594901 max_rtt_ns=357596691 accepted=true field_qualified=false`
- raw24x24: `supervised_load_test.go:348: supervised_post_stress index=1 same_socket=true idle_gap_ms=1100 rtt_ms=239`
- raw24x24: `supervised_load_test.go:348: supervised_post_stress index=2 same_socket=true idle_gap_ms=1100 rtt_ms=235`
- raw24x24: `supervised_load_test.go:348: supervised_post_stress index=3 same_socket=true idle_gap_ms=1100 rtt_ms=236`
- raw24x24: `supervised_load_test.go:348: supervised_post_stress index=4 same_socket=true idle_gap_ms=1100 rtt_ms=293`
- raw24x24: `supervised_load_test.go:348: supervised_post_stress index=5 same_socket=true idle_gap_ms=1100 rtt_ms=211`
- raw24x24: `supervised_load_test.go:348: supervised_post_stress index=6 same_socket=true idle_gap_ms=1100 rtt_ms=236`
- raw24x24: `supervised_load_test.go:353: supervised_carriers healthy=10 spontaneous_outages=0 epochs_preserved=true`
- http65: `field_https_test.go:507: field_130_result phase=download measured_ms=30000 warmup_s=10 streams_per_direction=24 background_streams=0 upload_mbps=0.000 download_mbps=115.571 tail_upload_mbps=0.000 tail_download_mbps=154.953 max_rtt_ms=478 probes=30 probe_errors=0 access_mbps=600 propagation_rtt_ms=65 qualification=PASS real_android_provider=NOT_RUN failure=<nil>`
- http65: `field_https_test.go:507: field_130_result phase=upload measured_ms=30000 warmup_s=10 streams_per_direction=24 background_streams=0 upload_mbps=92.484 download_mbps=0.000 tail_upload_mbps=80.478 tail_download_mbps=0.000 max_rtt_ms=385 probes=30 probe_errors=0 access_mbps=600 propagation_rtt_ms=65 qualification=PASS real_android_provider=NOT_RUN failure=<nil>`
- http65: `field_https_test.go:507: field_130_result phase=duplex measured_ms=30000 warmup_s=10 streams_per_direction=24 background_streams=0 upload_mbps=95.840 download_mbps=74.161 tail_upload_mbps=101.450 tail_download_mbps=138.491 max_rtt_ms=828 probes=30 probe_errors=0 access_mbps=600 propagation_rtt_ms=65 qualification=PASS real_android_provider=NOT_RUN failure=<nil>`
- http65: `field_https_test.go:507: field_130_result phase=download measured_ms=30000 warmup_s=10 streams_per_direction=24 background_streams=0 upload_mbps=0.000 download_mbps=137.870 tail_upload_mbps=0.000 tail_download_mbps=141.269 max_rtt_ms=444 probes=30 probe_errors=0 access_mbps=600 propagation_rtt_ms=65 qualification=PASS real_android_provider=NOT_RUN failure=<nil>`
- http65: `field_https_test.go:507: field_130_result phase=upload measured_ms=30000 warmup_s=10 streams_per_direction=24 background_streams=0 upload_mbps=104.692 download_mbps=0.000 tail_upload_mbps=92.773 tail_download_mbps=0.000 max_rtt_ms=346 probes=30 probe_errors=0 access_mbps=600 propagation_rtt_ms=65 qualification=PASS real_android_provider=NOT_RUN failure=<nil>`
- http65: `field_https_test.go:507: field_130_result phase=duplex measured_ms=30000 warmup_s=10 streams_per_direction=24 background_streams=0 upload_mbps=96.277 download_mbps=108.047 tail_upload_mbps=93.821 tail_download_mbps=88.841 max_rtt_ms=522 probes=30 probe_errors=0 access_mbps=600 propagation_rtt_ms=65 qualification=PASS real_android_provider=NOT_RUN failure=<nil>`
- http65: `field_https_test.go:507: field_130_result phase=download measured_ms=30000 warmup_s=10 streams_per_direction=24 background_streams=0 upload_mbps=0.000 download_mbps=122.919 tail_upload_mbps=0.000 tail_download_mbps=97.753 max_rtt_ms=456 probes=30 probe_errors=0 access_mbps=600 propagation_rtt_ms=65 qualification=PASS real_android_provider=NOT_RUN failure=<nil>`
- http65: `field_https_test.go:507: field_130_result phase=upload measured_ms=30000 warmup_s=10 streams_per_direction=24 background_streams=0 upload_mbps=85.940 download_mbps=0.000 tail_upload_mbps=65.851 tail_download_mbps=0.000 max_rtt_ms=405 probes=30 probe_errors=0 access_mbps=600 propagation_rtt_ms=65 qualification=PASS real_android_provider=NOT_RUN failure=<nil>`
- http65: `field_https_test.go:507: field_130_result phase=duplex measured_ms=30000 warmup_s=10 streams_per_direction=24 background_streams=0 upload_mbps=85.791 download_mbps=118.087 tail_upload_mbps=95.866 tail_download_mbps=61.761 max_rtt_ms=875 probes=30 probe_errors=0 access_mbps=600 propagation_rtt_ms=65 qualification=PASS real_android_provider=NOT_RUN failure=<nil>`
- http65: `field_https_test.go:556: field_post_stress index=1 tls_reused=true idle_gap_ms=1100 rtt_ms=305`
- http65: `field_https_test.go:556: field_post_stress index=2 tls_reused=true idle_gap_ms=1100 rtt_ms=278`
- http65: `field_https_test.go:556: field_post_stress index=3 tls_reused=true idle_gap_ms=1100 rtt_ms=307`
- http65: `field_https_test.go:556: field_post_stress index=4 tls_reused=true idle_gap_ms=1100 rtt_ms=255`
- http65: `field_https_test.go:556: field_post_stress index=5 tls_reused=true idle_gap_ms=1100 rtt_ms=249`
- http65: `field_https_test.go:556: field_post_stress index=6 tls_reused=true idle_gap_ms=1100 rtt_ms=284`
- http65: `field_https_test.go:561: supervised_carriers healthy=10 spontaneous_outages=0 epochs_preserved=true`
- http250_prior_harness: `field_https_test.go:503: field_130_result phase=download measured_ms=30000 warmup_s=10 streams_per_direction=24 background_streams=0 upload_mbps=0.000 download_mbps=3.146 tail_upload_mbps=0.000 tail_download_mbps=3.172 max_rtt_ms=957 probes=30 probe_errors=0 access_mbps=600 propagation_rtt_ms=250 qualification=NOT_ASSESSED real_android_provider=NOT_RUN failure=<nil>`
- http250_prior_harness: `field_https_test.go:503: field_130_result phase=upload measured_ms=30000 warmup_s=10 streams_per_direction=24 background_streams=0 upload_mbps=2.892 download_mbps=0.000 tail_upload_mbps=2.884 tail_download_mbps=0.000 max_rtt_ms=1028 probes=30 probe_errors=0 access_mbps=600 propagation_rtt_ms=250 qualification=NOT_ASSESSED real_android_provider=NOT_RUN failure=<nil>`
- http250_prior_harness: `field_https_test.go:503: field_130_result phase=duplex measured_ms=30000 warmup_s=10 streams_per_direction=24 background_streams=0 upload_mbps=1.188 download_mbps=2.700 tail_upload_mbps=1.468 tail_download_mbps=2.779 max_rtt_ms=1200 probes=30 probe_errors=0 access_mbps=600 propagation_rtt_ms=250 qualification=NOT_ASSESSED real_android_provider=NOT_RUN failure=<nil>`
- http250_prior_harness: `field_https_test.go:503: field_130_result phase=download measured_ms=30000 warmup_s=10 streams_per_direction=24 background_streams=0 upload_mbps=0.000 download_mbps=2.779 tail_upload_mbps=0.000 tail_download_mbps=2.779 max_rtt_ms=1001 probes=30 probe_errors=0 access_mbps=600 propagation_rtt_ms=250 qualification=NOT_ASSESSED real_android_provider=NOT_RUN failure=<nil>`
- http250_prior_harness: `field_https_test.go:503: field_130_result phase=upload measured_ms=30000 warmup_s=10 streams_per_direction=24 background_streams=0 upload_mbps=2.417 download_mbps=0.000 tail_upload_mbps=2.664 tail_download_mbps=0.000 max_rtt_ms=959 probes=30 probe_errors=1 access_mbps=600 propagation_rtt_ms=250 qualification=NOT_ASSESSED real_android_provider=NOT_RUN failure=upload body stopped id=upload/upload/21: unexpected EOF`
- http250_prior_harness: `field_https_test.go:503: field_130_result phase=duplex measured_ms=30000 warmup_s=10 streams_per_direction=24 background_streams=0 upload_mbps=1.522 download_mbps=2.875 tail_upload_mbps=1.389 tail_download_mbps=2.962 max_rtt_ms=1196 probes=30 probe_errors=1 access_mbps=600 propagation_rtt_ms=250 qualification=NOT_ASSESSED real_android_provider=NOT_RUN failure=upload body stopped id=upload/upload/8: unexpected EOF`
- http250_prior_harness: `field_https_test.go:503: field_130_result phase=download measured_ms=30000 warmup_s=10 streams_per_direction=24 background_streams=0 upload_mbps=0.000 download_mbps=2.639 tail_upload_mbps=0.000 tail_download_mbps=2.700 max_rtt_ms=971 probes=30 probe_errors=1 access_mbps=600 propagation_rtt_ms=250 qualification=NOT_ASSESSED real_android_provider=NOT_RUN failure=upload body stopped id=upload/upload/22: unexpected EOF`
- http250_prior_harness: `field_https_test.go:503: field_130_result phase=upload measured_ms=30000 warmup_s=10 streams_per_direction=24 background_streams=0 upload_mbps=1.493 download_mbps=0.000 tail_upload_mbps=1.904 tail_download_mbps=0.000 max_rtt_ms=1164 probes=30 probe_errors=1 access_mbps=600 propagation_rtt_ms=250 qualification=NOT_ASSESSED real_android_provider=NOT_RUN failure=upload body stopped id=upload/upload/17: unexpected EOF`
- http250_prior_harness: `field_https_test.go:503: field_130_result phase=duplex measured_ms=30000 warmup_s=10 streams_per_direction=24 background_streams=0 upload_mbps=1.850 download_mbps=2.840 tail_upload_mbps=1.835 tail_download_mbps=2.621 max_rtt_ms=1157 probes=30 probe_errors=1 access_mbps=600 propagation_rtt_ms=250 qualification=NOT_ASSESSED real_android_provider=NOT_RUN failure=upload body stopped id=upload/upload/1: unexpected EOF`
- prior100_raw: `supervised_load_test.go:252: supervised_result round=1 measured_ms=30000 upload_mbps=136.254 download_mbps=85.520 rtt_samples=30 p50_ms=258 p95_ms=391 max_ms=445 timeouts=0 missed=0 overlap=30 failure=<nil>`
- prior100_raw: `supervised_load_test.go:253: supervised_carriers healthy=10 spontaneous_outages=0 epochs_preserved=true`
- prior100_raw: `supervised_load_test.go:305: supervised_acceptance round=1 tier=100_mbps_lt1000ms minimum_verified_mbps=85.520111 max_rtt_ns=445984340 accepted=false field_qualified=false`
- prior100_raw: `supervised_load_test.go:252: supervised_result round=2 measured_ms=30000 upload_mbps=138.989 download_mbps=90.116 rtt_samples=30 p50_ms=257 p95_ms=328 max_ms=339 timeouts=0 missed=0 overlap=30 failure=<nil>`
- prior100_raw: `supervised_load_test.go:253: supervised_carriers healthy=10 spontaneous_outages=0 epochs_preserved=true`
- prior100_raw: `supervised_load_test.go:305: supervised_acceptance round=2 tier=100_mbps_lt1000ms minimum_verified_mbps=90.116369 max_rtt_ns=339474046 accepted=false field_qualified=false`
- prior100_raw: `supervised_load_test.go:252: supervised_result round=3 measured_ms=30000 upload_mbps=134.759 download_mbps=88.210 rtt_samples=30 p50_ms=250 p95_ms=365 max_ms=386 timeouts=0 missed=0 overlap=30 failure=<nil>`
- prior100_raw: `supervised_load_test.go:253: supervised_carriers healthy=10 spontaneous_outages=0 epochs_preserved=true`
- prior100_raw: `supervised_load_test.go:305: supervised_acceptance round=3 tier=100_mbps_lt1000ms minimum_verified_mbps=88.210494 max_rtt_ns=386794033 accepted=false field_qualified=false`
- prior100_http: `field_https_test.go:508: field_130_result phase=download measured_ms=30000 warmup_s=10 streams_per_direction=24 background_streams=0 upload_mbps=0.000 download_mbps=140.920 tail_upload_mbps=0.000 tail_download_mbps=151.074 max_rtt_ms=625 probes=30 probe_errors=0 access_mbps=600 propagation_rtt_ms=65 qualification=PASS real_android_provider=NOT_RUN failure=<nil>`
- prior100_http: `field_https_test.go:508: field_130_result phase=upload measured_ms=30000 warmup_s=10 streams_per_direction=24 background_streams=0 upload_mbps=91.838 download_mbps=0.000 tail_upload_mbps=77.568 tail_download_mbps=0.000 max_rtt_ms=363 probes=30 probe_errors=0 access_mbps=600 propagation_rtt_ms=65 qualification=FAIL real_android_provider=NOT_RUN failure=<nil>`
- prior100_http: `field_https_test.go:508: field_130_result phase=duplex measured_ms=30000 warmup_s=10 streams_per_direction=24 background_streams=0 upload_mbps=87.259 download_mbps=128.302 tail_upload_mbps=104.097 tail_download_mbps=138.963 max_rtt_ms=503 probes=30 probe_errors=0 access_mbps=600 propagation_rtt_ms=65 qualification=FAIL real_android_provider=NOT_RUN failure=<nil>`
- prior100_http: `field_https_test.go:508: field_130_result phase=download measured_ms=30000 warmup_s=10 streams_per_direction=24 background_streams=0 upload_mbps=0.000 download_mbps=127.402 tail_upload_mbps=0.000 tail_download_mbps=174.850 max_rtt_ms=468 probes=30 probe_errors=0 access_mbps=600 propagation_rtt_ms=65 qualification=PASS real_android_provider=NOT_RUN failure=<nil>`
- prior100_http: `field_https_test.go:508: field_130_result phase=upload measured_ms=30000 warmup_s=10 streams_per_direction=24 background_streams=0 upload_mbps=87.923 download_mbps=0.000 tail_upload_mbps=82.208 tail_download_mbps=0.000 max_rtt_ms=393 probes=30 probe_errors=0 access_mbps=600 propagation_rtt_ms=65 qualification=FAIL real_android_provider=NOT_RUN failure=<nil>`
- prior100_http: `field_https_test.go:508: field_130_result phase=duplex measured_ms=30000 warmup_s=10 streams_per_direction=24 background_streams=0 upload_mbps=85.206 download_mbps=128.931 tail_upload_mbps=84.541 tail_download_mbps=145.306 max_rtt_ms=652 probes=30 probe_errors=0 access_mbps=600 propagation_rtt_ms=65 qualification=FAIL real_android_provider=NOT_RUN failure=<nil>`
- prior100_http: `field_https_test.go:508: field_130_result phase=download measured_ms=30000 warmup_s=10 streams_per_direction=24 background_streams=0 upload_mbps=0.000 download_mbps=96.504 tail_upload_mbps=0.000 tail_download_mbps=14.601 max_rtt_ms=445 probes=30 probe_errors=0 access_mbps=600 propagation_rtt_ms=65 qualification=FAIL real_android_provider=NOT_RUN failure=<nil>`
- prior100_http: `field_https_test.go:508: field_130_result phase=upload measured_ms=30000 warmup_s=10 streams_per_direction=24 background_streams=0 upload_mbps=97.526 download_mbps=0.000 tail_upload_mbps=79.692 tail_download_mbps=0.000 max_rtt_ms=444 probes=30 probe_errors=0 access_mbps=600 propagation_rtt_ms=65 qualification=FAIL real_android_provider=NOT_RUN failure=<nil>`
- prior100_http: `field_https_test.go:508: field_130_result phase=duplex measured_ms=30000 warmup_s=10 streams_per_direction=24 background_streams=0 upload_mbps=84.690 download_mbps=132.619 tail_upload_mbps=72.693 tail_download_mbps=133.248 max_rtt_ms=559 probes=30 probe_errors=0 access_mbps=600 propagation_rtt_ms=65 qualification=FAIL real_android_provider=NOT_RUN failure=<nil>`

No performance FAIL was changed into PASS or waived. Baseline/earlier diagnostics are supporting evidence, not a fresh certification of the final source. See HANDOFF_META.json and the exact runtime-source fingerprint in each report.
