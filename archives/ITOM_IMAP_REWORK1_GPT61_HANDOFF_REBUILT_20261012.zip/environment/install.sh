#!/usr/bin/env bash
set -euo pipefail
command -v python3 >/dev/null
command -v gcc >/dev/null
ITOM_REPO_ROOT=${ITOM_REPO_ROOT:-/workspace/itom}
ITOM_TOOLS=/workspace/toolchains
mkdir -p "$ITOM_TOOLS"
ITOM_GO_ARCHIVE="$ITOM_TOOLS/go1.27.1.linux-amd64.tar.gz"
if [ ! -f "$ITOM_GO_ARCHIVE" ]; then
  curl -fL --retry 2 https://go.dev/dl/go1.27.1.linux-amd64.tar.gz -o "$ITOM_GO_ARCHIVE"
fi
printf '%s  %s\n' 63d339f0da5ab53635a56f2490a7984dfe12dfcff22ad749f63edaf590168445 "$ITOM_GO_ARCHIVE" | sha256sum -c -
if [ ! -x "$ITOM_TOOLS/go/bin/go" ]; then
  tar -xzf "$ITOM_GO_ARCHIVE" -C "$ITOM_TOOLS"
fi
export PATH="$ITOM_TOOLS/go/bin:$PATH"
export GOTOOLCHAIN=local GOWORK=off GOFLAGS=-mod=readonly
export GOCACHE="$ITOM_TOOLS/go-cache" GOPATH="$ITOM_TOOLS/gopath"
export GOPROXY="file://$ITOM_TOOLS/module-proxy,https://proxy.golang.org"
go version | python3 -c 'import sys; assert "go1.27.1 " in sys.stdin.read()'
go -C "$ITOM_REPO_ROOT/core" mod download
# The verified local file proxy is retained in the environment snapshot. A
# newly provisioned machine can use normal verified proxy/storage access.
go -C "$ITOM_REPO_ROOT/native" mod download
go -C "$ITOM_REPO_ROOT/core" test ./wire ./secure -count=1
