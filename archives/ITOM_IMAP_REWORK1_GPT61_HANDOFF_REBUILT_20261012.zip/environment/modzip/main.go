package main
import("os";"golang.org/x/mod/module";"golang.org/x/mod/zip")
func main(){f,e:=os.Create(os.Args[2]);if e!=nil{panic(e)};defer f.Close();if e=zip.CreateFromDir(f,module.Version{Path:"gvisor.dev/gvisor",Version:"v0.0.0-20260701204157-69c2d17aea96"},os.Args[1]);e!=nil{panic(e)}}
