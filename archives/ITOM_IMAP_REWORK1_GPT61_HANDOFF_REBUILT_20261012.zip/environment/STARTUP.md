# Reusable cloud setup

The install script was rerun successfully on this environment. It verifies the
official Go 1.27.1 archive checksum, preserves module checksums and readonly
dependency declarations, and exercises wire/security tests. Python3 and gcc
must already be available. Set ITOM_REPO_ROOT to the extracted source location
when it differs from /workspace/itom.

The current environment retains /workspace/toolchains, its verified module
cache, and a checksum-verified local gVisor module proxy. These large caches and
the toolchain are excluded from the source handoff. A clean machine needs normal
verified module-proxy/storage access. The original storage redirect was denied;
the exact pinned gVisor commit 69c2d17aea96 was fetched from GitHub codeload and
packed with Go's canonical module ZIP writer (modzip/main.go). Go accepted the
result against the unchanged native/go.sum. Do not change hashes or disable
TLS/module verification to bypass a download error.

The installed isolated checkout is /workspace/itom. Do not create worktrees
unless explicitly requested. No long-lived service is needed: the local tests
start and clean up their TLS/IMAP fixtures. Activate /workspace/toolchains/go/bin
in PATH and set GOTOOLCHAIN=local, GOWORK=off, GOFLAGS=-mod=readonly,
GOCACHE=/workspace/toolchains/go-cache and GOPATH=/workspace/toolchains/gopath.

The install_script and start_skill fields were saved as a cloud environment
configuration draft. Saving did not execute or publish that draft. Review and
save it in environment settings, then publish the environment if a reusable
cloud snapshot is wanted. Fresh-task restoration of this project's local-only
Git commits has not been verified; preserve and use the source archive.

Use tools/rework_gate.py for local correctness and separate synthetic
performance checks. Do not overlap performance runs or modify runtime sources
while measuring. Current acceptance is 50 Mbps in each active direction,
including sustained tails, every RTT strictly below 1000 ms and verified
post-stress established connections. Android/device and real-provider checks
remain separate.
